create table public.profiles (id uuid primary key references auth.users(id) on delete cascade, name text not null default '', phone text not null default '');
grant select on public.profiles to authenticated; grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "read own profile or admin" on public.profiles for select to authenticated using(id=auth.uid() or public.has_role(auth.uid(),'admin'));
create table public.reseller_accounts (user_id uuid primary key, username text not null unique, active boolean not null default true, created_at timestamptz not null default now());
grant select on public.reseller_accounts to authenticated; grant all on public.reseller_accounts to service_role;
alter table public.reseller_accounts enable row level security;
create policy "read own account or admin" on public.reseller_accounts for select to authenticated using(user_id=auth.uid() or public.has_role(auth.uid(),'admin'));
create or replace function public.create_signup_profile() returns trigger language plpgsql security definer set search_path=public as $$ begin insert into public.profiles(id) values(new.id) on conflict do nothing; return new; end $$;
create trigger create_signup_profile after insert on auth.users for each row execute function public.create_signup_profile();
insert into public.profiles(id) select id from auth.users on conflict do nothing;
create or replace function public.account_access_enabled(_id uuid) returns boolean language sql stable security definer set search_path=public as $$ select _id is not null and not exists(select 1 from public.reseller_accounts where user_id=_id and active=false) $$;
revoke all on function public.account_access_enabled(uuid) from public,anon; grant execute on function public.account_access_enabled(uuid) to authenticated,service_role;
do $$ declare t text; begin foreach t in array array['clients','servers','payments','notification_log','activity_log','settings','plans'] loop
 execute format('alter policy "own account rows" on public.%I using(owner_id=auth.uid() and public.account_access_enabled(auth.uid())) with check(owner_id=auth.uid() and public.account_access_enabled(auth.uid()))',t);
end loop; end $$;
alter policy "own account settings" on public.account_settings using(owner_id=auth.uid() and public.account_access_enabled(auth.uid())) with check(owner_id=auth.uid() and public.account_access_enabled(auth.uid()));
alter policy "own account plans" on public.account_plans using(owner_id=auth.uid() and public.account_access_enabled(auth.uid())) with check(owner_id=auth.uid() and public.account_access_enabled(auth.uid()));