-- Digital Fusion customer app: one-time reseller-issued activation codes.
-- Apply only after confirming this is the correct Supabase project.
create extension if not exists pgcrypto with schema extensions;

create table if not exists public.customer_app_access_codes (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  owner_id uuid not null,
  code_hash text not null unique,
  created_by uuid not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '7 days'),
  redeemed_at timestamptz,
  redeemed_by uuid references auth.users(id) on delete set null
);

create index if not exists customer_app_access_codes_client_idx
  on public.customer_app_access_codes(client_id, created_at desc);

create table if not exists public.customer_app_links (
  auth_user_id uuid primary key references auth.users(id) on delete cascade,
  client_id uuid not null unique references public.clients(id) on delete cascade,
  owner_id uuid not null,
  created_at timestamptz not null default now()
);

alter table public.customer_app_access_codes enable row level security;
alter table public.customer_app_links enable row level security;
-- No direct table policies: access is exclusively through narrowly-scoped SECURITY DEFINER RPCs.

create or replace function public.create_customer_app_code(_client_id uuid)
returns text
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_owner uuid;
  v_code text;
begin
  if auth.uid() is null then raise exception 'Faça login no painel para gerar o código.'; end if;

  select c.owner_id into v_owner
  from public.clients c
  where c.id = _client_id
    and (c.owner_id = auth.uid() or public.has_role(auth.uid(), 'admin'));

  if v_owner is null then raise exception 'Cliente não encontrado ou sem permissão.'; end if;

  -- A new code is a device replacement: invalidate any previously linked device.
  delete from public.customer_app_links where client_id = _client_id;
  delete from public.customer_app_access_codes where client_id = _client_id and redeemed_at is null;

  v_code := 'DF-' || upper(substr(encode(extensions.gen_random_bytes(8), 'hex'), 1, 12));

  insert into public.customer_app_access_codes(client_id, owner_id, code_hash, created_by)
  values (_client_id, v_owner, encode(extensions.digest(v_code, 'sha256'), 'hex'), auth.uid());

  return v_code;
end;
$$;

create or replace function public.activate_customer_app_code(_code text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_uid uuid := auth.uid();
  v_record public.customer_app_access_codes%rowtype;
begin
  if v_uid is null then raise exception 'Sessão do aplicativo não encontrada. Tente novamente.'; end if;

  if exists (select 1 from public.customer_app_links where auth_user_id = v_uid) then
    return jsonb_build_object('ok', true, 'already_linked', true);
  end if;

  select * into v_record
  from public.customer_app_access_codes
  where code_hash = encode(extensions.digest(upper(trim(_code)), 'sha256'), 'hex')
    and redeemed_at is null
    and expires_at > now()
  for update;

  if not found then raise exception 'Código inválido, expirado ou já utilizado. Peça um novo código ao seu revendedor.'; end if;

  insert into public.customer_app_links(auth_user_id, client_id, owner_id)
  values (v_uid, v_record.client_id, v_record.owner_id);

  update public.customer_app_access_codes
  set redeemed_at = now(), redeemed_by = v_uid
  where id = v_record.id;

  return jsonb_build_object('ok', true, 'already_linked', false);
exception
  when unique_violation then
    raise exception 'Este cliente já está vinculado a outro dispositivo. Peça ao revendedor para gerar um novo código.';
end;
$$;

create or replace function public.get_customer_app_profile()
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_profile jsonb;
begin
  select jsonb_build_object(
    'name', c.name,
    'plan', c.plan,
    'price', c.price,
    'due_date', c.due_date,
    'suspended', c.suspended,
    'status', case when c.suspended then 'suspenso' when c.due_date < current_date then 'vencido' when c.due_date <= current_date + 3 then 'vencendo' else 'ativo' end
  ) into v_profile
  from public.customer_app_links l
  join public.clients c on c.id = l.client_id and c.owner_id = l.owner_id
  where l.auth_user_id = auth.uid();

  return v_profile;
end;
$$;

revoke all on function public.create_customer_app_code(uuid) from public, anon;
grant execute on function public.create_customer_app_code(uuid) to authenticated;
revoke all on function public.activate_customer_app_code(text) from public, anon;
grant execute on function public.activate_customer_app_code(text) to authenticated;
revoke all on function public.get_customer_app_profile() from public, anon;
grant execute on function public.get_customer_app_profile() to authenticated;
