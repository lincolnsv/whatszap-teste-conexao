-- Preserve the existing account's data; no buyer receives legacy data.
alter table public.clients add column owner_id uuid default auth.uid();
alter table public.servers add column owner_id uuid default auth.uid();
alter table public.payments add column owner_id uuid default auth.uid();
alter table public.notification_log add column owner_id uuid default auth.uid();
alter table public.activity_log add column owner_id uuid default auth.uid();
alter table public.settings add column owner_id uuid default auth.uid();
alter table public.plans add column owner_id uuid default auth.uid();
update public.clients set owner_id='341d5deb-e357-435c-8299-00eed205b00a' where owner_id is null;
update public.servers set owner_id='341d5deb-e357-435c-8299-00eed205b00a' where owner_id is null;
update public.payments set owner_id='341d5deb-e357-435c-8299-00eed205b00a' where owner_id is null;
update public.notification_log set owner_id='341d5deb-e357-435c-8299-00eed205b00a' where owner_id is null;
update public.activity_log set owner_id='341d5deb-e357-435c-8299-00eed205b00a' where owner_id is null;
update public.settings set owner_id='341d5deb-e357-435c-8299-00eed205b00a' where owner_id is null;
update public.plans set owner_id='341d5deb-e357-435c-8299-00eed205b00a' where owner_id is null;
create table public.account_settings (
 owner_id uuid primary key default auth.uid(),
 system_name text not null default 'Fusion Gestão Pro', company_name text not null default '',
 pix_key text not null default '', pix_holder text not null default '',
 reminders_enabled boolean not null default false, send_hour integer not null default 9,
 template_name text not null default 'lembrete_vencimento', template_lang text not null default 'pt_BR',
 updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.account_settings to authenticated;
grant all on public.account_settings to service_role;
alter table public.account_settings enable row level security;
create policy "own account settings" on public.account_settings for all to authenticated using(owner_id=auth.uid()) with check(owner_id=auth.uid());
insert into public.account_settings select owner_id, system_name, company_name, pix_key, pix_holder, reminders_enabled, send_hour, template_name, template_lang, updated_at from public.settings;
create table public.account_plans (
 owner_id uuid not null default auth.uid(), code text not null, label text not null, months integer not null, price numeric(10,2) not null,
 primary key(owner_id,code), constraint positive_account_plan check(months>0 and price>=0)
);
grant select, insert, update, delete on public.account_plans to authenticated;
grant all on public.account_plans to service_role;
alter table public.account_plans enable row level security;
create policy "own account plans" on public.account_plans for all to authenticated using(owner_id=auth.uid()) with check(owner_id=auth.uid());
insert into public.account_plans select owner_id,code,label,months,price from public.plans;
comment on table public.settings is 'DEPRECATED: replaced by account_settings; legacy snapshot remains owner-restricted.';
comment on table public.plans is 'DEPRECATED: replaced by account_plans; retained for legacy client plan foreign key.';
do $$ declare t text; begin foreach t in array array['clients','servers','payments','notification_log','activity_log','settings','plans'] loop
 execute format('drop policy "admin all" on public.%I',t);
 execute format('create policy "own account rows" on public.%I for all to authenticated using(owner_id=auth.uid()) with check(owner_id=auth.uid())',t);
 execute format('create index on public.%I(owner_id)',t);
end loop; end $$;
drop policy "admin all" on public.whatsapp_webhook_events;
revoke all on public.whatsapp_webhook_events from authenticated, anon;
-- Protect ownership against transfers even through privileged updates.
create or replace function public.validate_account_links() returns trigger language plpgsql set search_path=public as $$
begin
 if new.owner_id is null then raise exception 'Conta proprietária obrigatória'; end if;
 if TG_OP='UPDATE' and new.owner_id is distinct from old.owner_id then raise exception 'Não é permitido transferir dados entre contas'; end if;
 if TG_TABLE_NAME in ('clients','payments') and new.server_id is not null then
  if not exists(select 1 from public.servers where id=new.server_id and owner_id=new.owner_id) then raise exception 'Servidor não pertence à sua conta'; end if;
 end if;
 if TG_TABLE_NAME in ('payments','notification_log') and new.client_id is not null then
  if not exists(select 1 from public.clients where id=new.client_id and owner_id=new.owner_id) then raise exception 'Cliente não pertence à sua conta'; end if;
 end if;
 if TG_TABLE_NAME='clients' and not exists(select 1 from public.account_plans where code=new.plan and owner_id=new.owner_id) then raise exception 'Plano não pertence à sua conta'; end if;
 return new;
end $$;
do $$ declare t text; begin foreach t in array array['clients','servers','payments','notification_log','activity_log','account_settings','account_plans'] loop
 execute format('create trigger validate_account_links before insert or update on public.%I for each row execute function public.validate_account_links()',t);
end loop; end $$;
-- Initialize only the authenticated caller, with neutral Pix/company values.
create or replace function public.ensure_account_defaults() returns void language plpgsql security invoker set search_path=public as $$
begin
 if auth.uid() is null then raise exception 'Acesso negado'; end if;
 insert into public.account_settings(owner_id) values(auth.uid()) on conflict do nothing;
 insert into public.account_plans(owner_id,code,label,months,price) values
 (auth.uid(),'mensal','Mensal',1,25),(auth.uid(),'trimestral','Trimestral',3,70),(auth.uid(),'semestral','Semestral',6,135),(auth.uid(),'anual','Anual',12,250) on conflict do nothing;
end $$;
revoke all on function public.ensure_account_defaults() from public,anon;
grant execute on function public.ensure_account_defaults() to authenticated;
create or replace function public.renew_client(_client_id uuid,_method text,_key text) returns jsonb language plpgsql security invoker set search_path=public as $$
declare c record; p record; base date; newdue date; pay_id uuid;
begin
 if auth.uid() is null then raise exception 'Acesso negado'; end if;
 select * into c from public.clients where id=_client_id and owner_id=auth.uid() for update;
 if not found then raise exception 'Cliente não encontrado'; end if;
 select * into p from public.account_plans where code=c.plan and owner_id=auth.uid();
 if not found then raise exception 'Plano não encontrado'; end if;
 base:=greatest(c.due_date,current_date); newdue:=(base+make_interval(months=>p.months))::date;
 insert into public.payments(owner_id,client_id,client_name,amount,method,plan,server_id,status,is_renewal,renewal_key) values(auth.uid(),c.id,c.name,c.price,_method,c.plan,c.server_id,'confirmado',true,_key) returning id into pay_id;
 update public.clients set due_date=newdue,suspended=false where id=c.id and owner_id=auth.uid();
 insert into public.activity_log(owner_id,kind,description) values(auth.uid(),'renovacao',format('Renovação de %s (%s): vencimento %s → %s',c.name,p.label,to_char(c.due_date,'DD/MM/YYYY'),to_char(newdue,'DD/MM/YYYY')));
 return jsonb_build_object('due_date',newdue,'payment_id',pay_id);
end $$;
revoke all on function public.renew_client(uuid,text,text) from public,anon;
grant execute on function public.renew_client(uuid,text,text) to authenticated;