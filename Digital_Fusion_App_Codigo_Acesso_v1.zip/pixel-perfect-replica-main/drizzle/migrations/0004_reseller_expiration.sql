ALTER TABLE public.reseller_accounts ADD COLUMN expires_on date;
CREATE OR REPLACE FUNCTION public.account_access_enabled(_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
 SELECT _id IS NOT NULL AND NOT EXISTS (
 SELECT 1 FROM public.reseller_accounts WHERE user_id = _id AND
 (NOT active OR (expires_on IS NOT NULL AND expires_on <= (now() AT TIME ZONE 'America/Sao_Paulo')::date))
 );
$$;
REVOKE ALL ON FUNCTION public.account_access_enabled(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.account_access_enabled(uuid) TO authenticated, service_role;