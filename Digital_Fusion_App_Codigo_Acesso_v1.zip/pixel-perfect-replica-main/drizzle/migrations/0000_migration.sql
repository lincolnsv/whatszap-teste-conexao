create type public.app_role as enum ('admin');
create table public.user_roles (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id) on delete cascade not null, role app_role not null, unique(user_id, role));
grant select on public.user_roles to authenticated; grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "own roles" on public.user_roles for select to authenticated using (user_id = auth.uid());
create or replace function public.has_role(_user_id uuid, _role app_role) returns boolean language sql stable security definer set search_path = public as $$ select exists(select 1 from public.user_roles where user_id=_user_id and role=_role) $$;

create table public.servers (id uuid primary key default gen_random_uuid(), name text not null, address text, description text, active boolean not null default true, notes text, created_at timestamptz not null default now());
create table public.plans (code text primary key, label text not null, months int not null, price numeric(10,2) not null);
insert into public.plans values ('mensal','Mensal',1,25),('trimestral','Trimestral',3,70),('semestral','Semestral',6,135),('anual','Anual',12,250);
create table public.clients (id uuid primary key default gen_random_uuid(), name text not null, phone text not null, server_id uuid references public.servers(id) on delete restrict, access_user text, access_password text, plan text not null references public.plans(code) default 'mensal', price numeric(10,2) not null default 25, signup_date date not null default current_date, due_date date not null, suspended boolean not null default false, whatsapp_consent boolean not null default false, notes text, created_at timestamptz not null default now());
create table public.payments (id uuid primary key default gen_random_uuid(), client_id uuid references public.clients(id) on delete set null, client_name text not null, amount numeric(10,2) not null, paid_at date not null default current_date, method text not null default 'pix' check (method in ('pix','dinheiro','cartao','outros')), plan text, server_id uuid references public.servers(id) on delete set null, status text not null default 'confirmado' check (status in ('confirmado','pendente')), is_renewal boolean not null default false, renewal_key text unique, notes text, created_at timestamptz not null default now());
create table public.notification_log (id uuid primary key default gen_random_uuid(), client_id uuid references public.clients(id) on delete set null, phone text, stage text not null, due_date date, status text not null default 'pendente', wa_message_id text unique, error text, attempts int not null default 0, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique(client_id, stage, due_date));
create table public.activity_log (id uuid primary key default gen_random_uuid(), kind text not null, description text not null, created_at timestamptz not null default now());
create table public.settings (id int primary key default 1 check (id=1), system_name text not null default 'Fusion Gestão Pro', company_name text not null default 'Digital Fusion', pix_key text not null default '64984599170', pix_holder text not null default 'Lincoln Silva Medeiros', reminders_enabled boolean not null default false, send_hour int not null default 9, template_name text not null default 'lembrete_vencimento', template_lang text not null default 'pt_BR', updated_at timestamptz not null default now());
insert into public.settings (id) values (1);
create table public.whatsapp_webhook_events (id uuid primary key default gen_random_uuid(), delivery_id text unique not null, event text not null, payload jsonb not null, received_at timestamptz not null default now(), processed_at timestamptz, processing_error text);

do $$ declare t text; begin foreach t in array array['servers','plans','clients','payments','notification_log','activity_log','settings','whatsapp_webhook_events'] loop
 execute format('grant select, insert, update, delete on public.%I to authenticated; grant all on public.%I to service_role; alter table public.%I enable row level security; create policy "admin all" on public.%I for all to authenticated using (public.has_role(auth.uid(),''admin'')) with check (public.has_role(auth.uid(),''admin''));', t,t,t,t);
end loop; end $$;

create or replace function public.renew_client(_client_id uuid, _method text, _key text) returns jsonb language plpgsql security invoker set search_path=public as $$
declare c record; p record; base date; newdue date; pay_id uuid;
begin
 if not public.has_role(auth.uid(),'admin') then raise exception 'forbidden'; end if;
 select * into c from clients where id=_client_id for update; if not found then raise exception 'cliente não encontrado'; end if;
 select * into p from plans where code=c.plan;
 base := greatest(c.due_date, current_date);
 newdue := (base + make_interval(months => p.months))::date;
 insert into payments(client_id, client_name, amount, method, plan, server_id, status, is_renewal, renewal_key) values (c.id, c.name, c.price, _method, c.plan, c.server_id, 'confirmado', true, _key) returning id into pay_id;
 update clients set due_date=newdue, suspended=false where id=c.id;
 insert into activity_log(kind, description) values ('renovacao', format('Renovação de %s (%s): vencimento %s → %s', c.name, p.label, to_char(c.due_date,'DD/MM/YYYY'), to_char(newdue,'DD/MM/YYYY')));
 return jsonb_build_object('due_date', newdue, 'payment_id', pay_id);
end $$;