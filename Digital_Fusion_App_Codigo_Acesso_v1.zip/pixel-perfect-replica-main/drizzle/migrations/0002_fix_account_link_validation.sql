create or replace function public.validate_account_links() returns trigger language plpgsql set search_path=public as $$
declare row_data jsonb; linked_server uuid; linked_client uuid;
begin
 if new.owner_id is null then raise exception 'Conta proprietária obrigatória'; end if;
 if TG_OP='UPDATE' then
  if new.owner_id is distinct from old.owner_id then raise exception 'Não é permitido transferir dados entre contas'; end if;
 end if;
 row_data:=to_jsonb(new);
 linked_server:=(row_data->>'server_id')::uuid;
 linked_client:=(row_data->>'client_id')::uuid;
 if TG_TABLE_NAME in ('clients','payments') and linked_server is not null then
  if not exists(select 1 from public.servers where id=linked_server and owner_id=new.owner_id) then raise exception 'Servidor não pertence à sua conta'; end if;
 end if;
 if TG_TABLE_NAME in ('payments','notification_log') and linked_client is not null then
  if not exists(select 1 from public.clients where id=linked_client and owner_id=new.owner_id) then raise exception 'Cliente não pertence à sua conta'; end if;
 end if;
 if TG_TABLE_NAME='clients' then
  if not exists(select 1 from public.account_plans where code=row_data->>'plan' and owner_id=new.owner_id) then raise exception 'Plano não pertence à sua conta'; end if;
 end if;
 return new;
end $$;