<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Estrela-guia

Revendedores mantêm seus clientes renovados e pagando.

## Métrica

Assinaturas de clientes renovadas a cada semana
