import type { ReactNode } from "react";
import type { LucideIcon } from "lucide-react";
import { Inbox, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { STATUS_LABEL, type ClientStatus } from "@/lib/business";

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3 animate-in-up">
      <div><h1 className="text-2xl font-semibold md:text-3xl">{title}</h1>{subtitle && <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>}</div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}
const TONES = {
  primary: "bg-accent text-accent-foreground",
  success: "bg-success/15 text-success",
  warning: "bg-warning/20 text-warning-foreground",
  danger: "bg-destructive/10 text-destructive",
  info: "bg-chart-2/10 text-chart-2",
} as const;
export function StatCard({ label, value, icon: Icon, tone = "primary", hint }: { label: string; value: ReactNode; icon: LucideIcon; tone?: keyof typeof TONES; hint?: string }) {
  return (
    <div className="rounded-xl border bg-card p-4 shadow-card animate-in-up">
      <div className="flex items-start justify-between gap-2">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</p>
        <span className={cn("flex h-8 w-8 items-center justify-center rounded-lg", TONES[tone])}><Icon className="h-4 w-4" /></span>
      </div>
      <p className="mt-2 font-display text-2xl font-semibold">{value}</p>
      {hint && <p className="mt-0.5 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}
const STATUS_TONE: Record<ClientStatus, string> = { ativo: TONES.success, vencendo: TONES.warning, vencido: TONES.danger, suspenso: "bg-muted text-muted-foreground" };
export function StatusBadge({ status }: { status: ClientStatus }) {
  return <span className={cn("inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold", STATUS_TONE[status])}>{STATUS_LABEL[status]}</span>;
}
export function Pill({ children, tone = "primary" }: { children: ReactNode; tone?: keyof typeof TONES }) {
  return <span className={cn("inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold", TONES[tone])}>{children}</span>;
}
export function Panel({ title, children, actions, className }: { title?: string; children: ReactNode; actions?: ReactNode; className?: string }) {
  return (
    <section className={cn("rounded-xl border bg-card shadow-card animate-in-up", className)}>
      {title && <div className="flex items-center justify-between border-b px-4 py-3"><h3 className="text-sm font-semibold">{title}</h3>{actions}</div>}
      <div className="p-4">{children}</div>
    </section>
  );
}
export function Empty({ text = "Nenhum registro encontrado." }: { text?: string }) {
  return <div className="flex flex-col items-center gap-2 py-10 text-sm text-muted-foreground"><Inbox className="h-8 w-8 opacity-50" />{text}</div>;
}
export function Loading() {
  return <div className="flex justify-center py-16 text-muted-foreground"><Loader2 className="h-6 w-6 animate-spin" /></div>;
}
export function ErrorBox({ error }: { error: unknown }) {
  return <div className="rounded-lg bg-destructive/10 p-4 text-sm text-destructive">Erro ao carregar: {error instanceof Error ? error.message : String(error)}</div>;
}
