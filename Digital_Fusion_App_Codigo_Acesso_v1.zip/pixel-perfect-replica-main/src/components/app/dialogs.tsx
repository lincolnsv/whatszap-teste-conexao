import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { type Client, usePlans, useServers, logActivity, useRefresh, usePayments, useNotifications } from "@/lib/data";
import { addMonths, brl, computeRenewal, fmtDate, fmtDateTime, METHOD_LABEL, todayISO } from "@/lib/business";
import { Empty, Pill } from "./ui";

const F = ({ label, children, className }: { label: string; children: React.ReactNode; className?: string }) => (
  <div className={"space-y-1.5 " + (className ?? "")}><Label>{label}</Label>{children}</div>
);

export function ClientDialog({ open, onOpenChange, client }: { open: boolean; onOpenChange: (o: boolean) => void; client?: Client | null }) {
  const { data: plans = [] } = usePlans();
  const { data: servers = [] } = useServers();
  const refresh = useRefresh();
  const empty = { name: "", phone: "", server_id: "", access_user: "", access_password: "", plan: "mensal", price: 25, signup_date: todayISO(), due_date: addMonths(todayISO(), 1), suspended: false, whatsapp_consent: false, notes: "" };
  const [f, setF] = useState<any>(empty);
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (open) setF(client ? { ...empty, ...client, server_id: client.server_id ?? "", notes: client.notes ?? "", access_user: client.access_user ?? "", access_password: client.access_password ?? "" } : empty); }, [open, client]); // eslint-disable-line
  const set = (k: string, v: unknown) => setF((p: any) => ({ ...p, [k]: v }));

  async function save() {
    if (f.name.trim().length < 2) return void toast.error("Informe o nome do cliente.");
    if (f.phone.replace(/\D/g, "").length < 10) return void toast.error("Telefone inválido: informe com DDD.");
    if (!f.due_date) return void toast.error("Informe a data de vencimento.");
    setBusy(true);
    const row = { name: f.name.trim(), phone: f.phone.trim(), server_id: f.server_id || null, access_user: f.access_user || null, access_password: f.access_password || null, plan: f.plan, price: Number(f.price), signup_date: f.signup_date, due_date: f.due_date, suspended: f.suspended, whatsapp_consent: f.whatsapp_consent, notes: f.notes || null };
    const { error } = client ? await supabase.from("clients").update(row).eq("id", client.id) : await supabase.from("clients").insert(row);
    setBusy(false);
    if (error) return void toast.error(error.message);
    await logActivity(client ? "cliente_editado" : "cliente_criado", `${client ? "Cliente alterado" : "Cliente cadastrado"}: ${row.name}`);
    toast.success(client ? "Cliente atualizado" : "Cliente cadastrado");
    await refresh("clients"); onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader><DialogTitle>{client ? "Editar cliente" : "Novo cliente"}</DialogTitle></DialogHeader>
        <div className="grid gap-4 sm:grid-cols-2">
          <F label="Nome do cliente"><Input value={f.name} onChange={(e) => set("name", e.target.value)} /></F>
          <F label="Telefone com DDD"><Input value={f.phone} placeholder="(64) 98459-9170" onChange={(e) => set("phone", e.target.value)} /></F>
          <F label="Servidor">
            <Select value={f.server_id || "none"} onValueChange={(v) => set("server_id", v === "none" ? "" : v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="none">Sem servidor</SelectItem>{servers.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}{!s.active && " (inativo)"}</SelectItem>)}</SelectContent>
            </Select>
          </F>
          <F label="Plano">
            <Select value={f.plan} onValueChange={(v) => { const p = plans.find((x) => x.code === v); setF((o: any) => ({ ...o, plan: v, price: p ? Number(p.price) : o.price, due_date: client ? o.due_date : addMonths(o.signup_date, p?.months ?? 1) })); }}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{plans.map((p) => <SelectItem key={p.code} value={p.code}>{p.label} — {brl(p.price)}</SelectItem>)}</SelectContent>
            </Select>
          </F>
          <F label="Usuário de acesso"><Input value={f.access_user} onChange={(e) => set("access_user", e.target.value)} autoComplete="off" /></F>
          <F label="Senha de acesso"><Input value={f.access_password} onChange={(e) => set("access_password", e.target.value)} autoComplete="off" /></F>
          <F label="Valor da assinatura (R$)"><Input type="number" step="0.01" min="0" value={f.price} onChange={(e) => set("price", e.target.value)} /></F>
          <F label="Data de cadastro"><Input type="date" value={f.signup_date} onChange={(e) => set("signup_date", e.target.value)} /></F>
          <F label="Data de vencimento"><Input type="date" value={f.due_date} onChange={(e) => set("due_date", e.target.value)} /></F>
          <div className="flex flex-col justify-end gap-3">
            <label className="flex items-center gap-2 text-sm"><Switch checked={f.suspended} onCheckedChange={(v) => set("suspended", v)} />Suspenso</label>
            <label className="flex items-center gap-2 text-sm"><Switch checked={f.whatsapp_consent} onCheckedChange={(v) => set("whatsapp_consent", v)} />Aceita lembretes no WhatsApp</label>
          </div>
          <F label="Observações" className="sm:col-span-2"><Textarea value={f.notes} onChange={(e) => set("notes", e.target.value)} /></F>
        </div>
        <DialogFooter><Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button><Button onClick={save} disabled={busy}>{busy && <Loader2 className="h-4 w-4 animate-spin" />}Salvar</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function RenewDialog({ client, onOpenChange }: { client: Client | null; onOpenChange: (o: boolean) => void }) {
  const { data: plans = [] } = usePlans();
  const refresh = useRefresh();
  const [method, setMethod] = useState("pix");
  const [busy, setBusy] = useState(false);
  const key = useMemo(() => (client ? crypto.randomUUID() : ""), [client]);
  const plan = plans.find((p) => p.code === client?.plan);
  const newDue = client && plan ? computeRenewal(client.due_date, plan.months, todayISO()) : null;
  async function confirm() {
    if (!client) return;
    setBusy(true);
    const { error } = await supabase.rpc("renew_client", { _client_id: client.id, _method: method, _key: key });
    setBusy(false);
    if (error) return void toast.error(error.code === "23505" ? "Esta renovação já foi registrada." : error.message);
    toast.success("Assinatura renovada e pagamento registrado");
    await refresh("clients", "payments"); onOpenChange(false);
  }
  return (
    <Dialog open={!!client} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader><DialogTitle>Renovar assinatura</DialogTitle><DialogDescription>Confirme somente após receber o pagamento.</DialogDescription></DialogHeader>
        {client && (
          <div className="space-y-3 text-sm">
            <div className="grid grid-cols-2 gap-2 rounded-lg bg-muted p-3">
              <span className="text-muted-foreground">Cliente</span><span className="font-medium">{client.name}</span>
              <span className="text-muted-foreground">Plano</span><span>{plan?.label}</span>
              <span className="text-muted-foreground">Valor</span><span>{brl(client.price)}</span>
              <span className="text-muted-foreground">Vencimento atual</span><span>{fmtDate(client.due_date)}</span>
              <span className="text-muted-foreground">Novo vencimento</span><span className="font-semibold text-primary">{fmtDate(newDue)}</span>
            </div>
            <F label="Forma de pagamento">
              <Select value={method} onValueChange={setMethod}><SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{Object.entries(METHOD_LABEL).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent></Select>
            </F>
          </div>
        )}
        <DialogFooter><Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button><Button onClick={confirm} disabled={busy}>{busy && <Loader2 className="h-4 w-4 animate-spin" />}Confirmar pagamento e renovar</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function PaymentDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const { data: plans = [] } = usePlans();
  const { data: servers = [] } = useServers();
  const refresh = useRefresh();
  const [clients, setClients] = useState<Client[]>([]);
  const empty = { client_id: "", client_name: "", amount: "", paid_at: todayISO(), method: "pix", plan: "mensal", server_id: "", status: "confirmado", notes: "" };
  const [f, setF] = useState<any>(empty);
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (open) { setF(empty); supabase.from("clients").select("*").order("name").then(({ data }) => setClients(data ?? [])); } }, [open]); // eslint-disable-line
  const set = (k: string, v: unknown) => setF((p: any) => ({ ...p, [k]: v }));
  async function save() {
    if (!f.client_name.trim()) return void toast.error("Informe o cliente.");
    if (!(Number(f.amount) > 0)) return void toast.error("Informe um valor válido.");
    setBusy(true);
    const { error } = await supabase.from("payments").insert({ client_id: f.client_id || null, client_name: f.client_name.trim(), amount: Number(f.amount), paid_at: f.paid_at, method: f.method, plan: f.plan, server_id: f.server_id || null, status: f.status, notes: f.notes || null });
    setBusy(false);
    if (error) return void toast.error(error.message);
    await logActivity("pagamento", `Pagamento ${f.status} de ${brl(f.amount)} — ${f.client_name}`);
    toast.success("Pagamento registrado"); await refresh("payments"); onOpenChange(false);
  }
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader><DialogTitle>Registrar pagamento</DialogTitle><DialogDescription>Para renovar a assinatura, use “Renovar” na lista de clientes.</DialogDescription></DialogHeader>
        <div className="grid gap-4 sm:grid-cols-2">
          <F label="Cliente" className="sm:col-span-2">
            <Select value={f.client_id || "manual"} onValueChange={(v) => { const c = clients.find((x) => x.id === v); setF((o: any) => c ? { ...o, client_id: c.id, client_name: c.name, amount: c.price, plan: c.plan, server_id: c.server_id ?? "" } : { ...o, client_id: "", client_name: "" }); }}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="manual">Digitar nome…</SelectItem>{clients.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
            </Select>
            {!f.client_id && <Input className="mt-2" placeholder="Nome do cliente" value={f.client_name} onChange={(e) => set("client_name", e.target.value)} />}
          </F>
          <F label="Valor (R$)"><Input type="number" step="0.01" value={f.amount} onChange={(e) => set("amount", e.target.value)} /></F>
          <F label="Data do pagamento"><Input type="date" value={f.paid_at} onChange={(e) => set("paid_at", e.target.value)} /></F>
          <F label="Forma"><Select value={f.method} onValueChange={(v) => set("method", v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{Object.entries(METHOD_LABEL).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent></Select></F>
          <F label="Situação"><Select value={f.status} onValueChange={(v) => set("status", v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="confirmado">Confirmado</SelectItem><SelectItem value="pendente">Pendente</SelectItem></SelectContent></Select></F>
          <F label="Plano"><Select value={f.plan} onValueChange={(v) => set("plan", v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{plans.map((p) => <SelectItem key={p.code} value={p.code}>{p.label}</SelectItem>)}</SelectContent></Select></F>
          <F label="Servidor"><Select value={f.server_id || "none"} onValueChange={(v) => set("server_id", v === "none" ? "" : v)}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="none">—</SelectItem>{servers.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent></Select></F>
          <F label="Observações" className="sm:col-span-2"><Textarea value={f.notes} onChange={(e) => set("notes", e.target.value)} /></F>
        </div>
        <DialogFooter><Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button><Button onClick={save} disabled={busy}>{busy && <Loader2 className="h-4 w-4 animate-spin" />}Registrar</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function HistoryDialog({ client, onOpenChange }: { client: Client | null; onOpenChange: (o: boolean) => void }) {
  const { data: payments = [] } = usePayments();
  const { data: notes = [] } = useNotifications();
  const ps = payments.filter((p) => p.client_id === client?.id);
  const ns = notes.filter((n) => n.client_id === client?.id);
  return (
    <Dialog open={!!client} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader><DialogTitle>Histórico — {client?.name}</DialogTitle><DialogDescription>Vencimento atual: {fmtDate(client?.due_date)}</DialogDescription></DialogHeader>
        <h4 className="text-sm font-semibold">Pagamentos</h4>
        {ps.length === 0 ? <Empty text="Nenhum pagamento." /> : (
          <Table><TableHeader><TableRow><TableHead>Data</TableHead><TableHead>Valor</TableHead><TableHead>Forma</TableHead><TableHead>Tipo</TableHead></TableRow></TableHeader>
            <TableBody>{ps.map((p) => <TableRow key={p.id}><TableCell>{fmtDate(p.paid_at)}</TableCell><TableCell>{brl(p.amount)}</TableCell><TableCell>{METHOD_LABEL[p.method]}</TableCell><TableCell>{p.is_renewal ? <Pill>Renovação</Pill> : <Pill tone={p.status === "pendente" ? "warning" : "success"}>{p.status}</Pill>}</TableCell></TableRow>)}</TableBody></Table>
        )}
        <h4 className="mt-2 text-sm font-semibold">Notificações</h4>
        {ns.length === 0 ? <Empty text="Nenhuma notificação." /> : (
          <ul className="space-y-1 text-sm">{ns.map((n) => <li key={n.id} className="flex justify-between gap-2 rounded-md bg-muted px-3 py-1.5"><span>{fmtDateTime(n.created_at)} · {n.stage}</span><span className="font-medium">{n.status}</span></li>)}</ul>
        )}
      </DialogContent>
    </Dialog>
  );
}
