import { createClient } from "@supabase/supabase-js";
import type { Database } from "./types";

const url = import.meta.env.VITE_SUPABASE_URL as string;
const key = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string;

if (!url || !key) {
  throw new Error("O aplicativo Digital Fusion não está configurado. Verifique as variáveis públicas do Supabase.");
}

// Separate auth storage prevents the customer app from overwriting the reseller's panel session.
export const customerSupabase = createClient<Database>(url, key, {
  auth: {
    storageKey: "digital-fusion-customer-auth",
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false,
  },
});
