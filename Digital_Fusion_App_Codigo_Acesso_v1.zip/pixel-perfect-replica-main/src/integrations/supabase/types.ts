export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      account_plans: {
        Row: {
          code: string
          label: string
          months: number
          owner_id: string
          price: number
        }
        Insert: {
          code: string
          label: string
          months: number
          owner_id?: string
          price: number
        }
        Update: {
          code?: string
          label?: string
          months?: number
          owner_id?: string
          price?: number
        }
        Relationships: []
      }
      account_settings: {
        Row: {
          company_name: string
          owner_id: string
          pix_holder: string
          pix_key: string
          reminders_enabled: boolean
          send_hour: number
          system_name: string
          template_lang: string
          template_name: string
          updated_at: string
        }
        Insert: {
          company_name?: string
          owner_id?: string
          pix_holder?: string
          pix_key?: string
          reminders_enabled?: boolean
          send_hour?: number
          system_name?: string
          template_lang?: string
          template_name?: string
          updated_at?: string
        }
        Update: {
          company_name?: string
          owner_id?: string
          pix_holder?: string
          pix_key?: string
          reminders_enabled?: boolean
          send_hour?: number
          system_name?: string
          template_lang?: string
          template_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      activity_log: {
        Row: {
          created_at: string
          description: string
          id: string
          kind: string
          owner_id: string | null
        }
        Insert: {
          created_at?: string
          description: string
          id?: string
          kind: string
          owner_id?: string | null
        }
        Update: {
          created_at?: string
          description?: string
          id?: string
          kind?: string
          owner_id?: string | null
        }
        Relationships: []
      }
      clients: {
        Row: {
          access_password: string | null
          access_user: string | null
          created_at: string
          due_date: string
          id: string
          name: string
          notes: string | null
          owner_id: string | null
          phone: string
          plan: string
          price: number
          server_id: string | null
          signup_date: string
          suspended: boolean
          whatsapp_consent: boolean
        }
        Insert: {
          access_password?: string | null
          access_user?: string | null
          created_at?: string
          due_date: string
          id?: string
          name: string
          notes?: string | null
          owner_id?: string | null
          phone: string
          plan?: string
          price?: number
          server_id?: string | null
          signup_date?: string
          suspended?: boolean
          whatsapp_consent?: boolean
        }
        Update: {
          access_password?: string | null
          access_user?: string | null
          created_at?: string
          due_date?: string
          id?: string
          name?: string
          notes?: string | null
          owner_id?: string | null
          phone?: string
          plan?: string
          price?: number
          server_id?: string | null
          signup_date?: string
          suspended?: boolean
          whatsapp_consent?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "clients_plan_fkey"
            columns: ["plan"]
            isOneToOne: false
            referencedRelation: "plans"
            referencedColumns: ["code"]
          },
          {
            foreignKeyName: "clients_server_id_fkey"
            columns: ["server_id"]
            isOneToOne: false
            referencedRelation: "servers"
            referencedColumns: ["id"]
          },
        ]
      }
      notification_log: {
        Row: {
          attempts: number
          client_id: string | null
          created_at: string
          due_date: string | null
          error: string | null
          id: string
          owner_id: string | null
          phone: string | null
          stage: string
          status: string
          updated_at: string
          wa_message_id: string | null
        }
        Insert: {
          attempts?: number
          client_id?: string | null
          created_at?: string
          due_date?: string | null
          error?: string | null
          id?: string
          owner_id?: string | null
          phone?: string | null
          stage: string
          status?: string
          updated_at?: string
          wa_message_id?: string | null
        }
        Update: {
          attempts?: number
          client_id?: string | null
          created_at?: string
          due_date?: string | null
          error?: string | null
          id?: string
          owner_id?: string | null
          phone?: string | null
          stage?: string
          status?: string
          updated_at?: string
          wa_message_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "notification_log_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      payments: {
        Row: {
          amount: number
          client_id: string | null
          client_name: string
          created_at: string
          id: string
          is_renewal: boolean
          method: string
          notes: string | null
          owner_id: string | null
          paid_at: string
          plan: string | null
          renewal_key: string | null
          server_id: string | null
          status: string
        }
        Insert: {
          amount: number
          client_id?: string | null
          client_name: string
          created_at?: string
          id?: string
          is_renewal?: boolean
          method?: string
          notes?: string | null
          owner_id?: string | null
          paid_at?: string
          plan?: string | null
          renewal_key?: string | null
          server_id?: string | null
          status?: string
        }
        Update: {
          amount?: number
          client_id?: string | null
          client_name?: string
          created_at?: string
          id?: string
          is_renewal?: boolean
          method?: string
          notes?: string | null
          owner_id?: string | null
          paid_at?: string
          plan?: string | null
          renewal_key?: string | null
          server_id?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "payments_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payments_server_id_fkey"
            columns: ["server_id"]
            isOneToOne: false
            referencedRelation: "servers"
            referencedColumns: ["id"]
          },
        ]
      }
      plans: {
        Row: {
          code: string
          label: string
          months: number
          owner_id: string | null
          price: number
        }
        Insert: {
          code: string
          label: string
          months: number
          owner_id?: string | null
          price: number
        }
        Update: {
          code?: string
          label?: string
          months?: number
          owner_id?: string | null
          price?: number
        }
        Relationships: []
      }
      profiles: {
        Row: {
          id: string
          name: string
          phone: string
        }
        Insert: {
          id: string
          name?: string
          phone?: string
        }
        Update: {
          id?: string
          name?: string
          phone?: string
        }
        Relationships: []
      }
      reseller_accounts: {
        Row: {
          active: boolean
          created_at: string
          expires_on: string | null
          user_id: string
          username: string
        }
        Insert: {
          active?: boolean
          created_at?: string
          expires_on?: string | null
          user_id: string
          username: string
        }
        Update: {
          active?: boolean
          created_at?: string
          expires_on?: string | null
          user_id?: string
          username?: string
        }
        Relationships: []
      }
      servers: {
        Row: {
          active: boolean
          address: string | null
          created_at: string
          description: string | null
          id: string
          name: string
          notes: string | null
          owner_id: string | null
        }
        Insert: {
          active?: boolean
          address?: string | null
          created_at?: string
          description?: string | null
          id?: string
          name: string
          notes?: string | null
          owner_id?: string | null
        }
        Update: {
          active?: boolean
          address?: string | null
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          notes?: string | null
          owner_id?: string | null
        }
        Relationships: []
      }
      settings: {
        Row: {
          company_name: string
          id: number
          owner_id: string | null
          pix_holder: string
          pix_key: string
          reminders_enabled: boolean
          send_hour: number
          system_name: string
          template_lang: string
          template_name: string
          updated_at: string
        }
        Insert: {
          company_name?: string
          id?: number
          owner_id?: string | null
          pix_holder?: string
          pix_key?: string
          reminders_enabled?: boolean
          send_hour?: number
          system_name?: string
          template_lang?: string
          template_name?: string
          updated_at?: string
        }
        Update: {
          company_name?: string
          id?: number
          owner_id?: string | null
          pix_holder?: string
          pix_key?: string
          reminders_enabled?: boolean
          send_hour?: number
          system_name?: string
          template_lang?: string
          template_name?: string
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      whatsapp_webhook_events: {
        Row: {
          delivery_id: string
          event: string
          id: string
          payload: Json
          processed_at: string | null
          processing_error: string | null
          received_at: string
        }
        Insert: {
          delivery_id: string
          event: string
          id?: string
          payload: Json
          processed_at?: string | null
          processing_error?: string | null
          received_at?: string
        }
        Update: {
          delivery_id?: string
          event?: string
          id?: string
          payload?: Json
          processed_at?: string | null
          processing_error?: string | null
          received_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      account_access_enabled: { Args: { _id: string }; Returns: boolean }
      ensure_account_defaults: { Args: never; Returns: undefined }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      renew_client: {
        Args: { _client_id: string; _key: string; _method: string }
        Returns: Json
      }
    }
    Enums: {
      app_role: "admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin"],
    },
  },
} as const
