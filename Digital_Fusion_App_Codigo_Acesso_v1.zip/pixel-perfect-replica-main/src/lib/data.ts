import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouteContext } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

export type Client = Tables<"clients">;
export type ServerRow = Tables<"servers">;
export type Plan = Tables<"account_plans">;
export type Payment = Tables<"payments">;
export type Settings = Tables<"account_settings">;

async function unwrap<T>(p: PromiseLike<{ data: T | null; error: { message: string } | null }>): Promise<T> {
  const { data, error } = await p; if (error) throw new Error(error.message); return data as T;
}
export function useAccountId() {
  return useRouteContext({ from: "/_authenticated" }).user.id;
}
async function ensureDefaults() {
  const { error } = await supabase.rpc("ensure_account_defaults");
  if (error) throw new Error(error.message);
}
export function useClients() {
  const id = useAccountId();
  return useQuery({ queryKey: ["clients", id], queryFn: () => unwrap<Client[]>(supabase.from("clients").select("*").eq("owner_id", id).order("name").limit(5000)) });
}
export function useServers() {
  const id = useAccountId();
  return useQuery({ queryKey: ["servers", id], queryFn: () => unwrap<ServerRow[]>(supabase.from("servers").select("*").eq("owner_id", id).order("name")) });
}
export function usePlans() {
  const id = useAccountId();
  return useQuery({ queryKey: ["plans", id], queryFn: async () => { await ensureDefaults(); return unwrap<Plan[]>(supabase.from("account_plans").select("*").eq("owner_id", id).order("months")); } });
}
export function usePayments() {
  const id = useAccountId();
  return useQuery({ queryKey: ["payments", id], queryFn: () => unwrap<Payment[]>(supabase.from("payments").select("*").eq("owner_id", id).order("paid_at", { ascending: false }).limit(5000)) });
}
export function useSettings() {
  const id = useAccountId();
  return useQuery({ queryKey: ["settings", id], queryFn: async () => { await ensureDefaults(); return unwrap<Settings>(supabase.from("account_settings").select("*").eq("owner_id", id).single()); } });
}
export function useActivity() {
  const id = useAccountId();
  return useQuery({ queryKey: ["activity", id], queryFn: () => unwrap<Tables<"activity_log">[]>(supabase.from("activity_log").select("*").eq("owner_id", id).order("created_at", { ascending: false }).limit(200)) });
}
export function useNotifications() {
  const id = useAccountId();
  return useQuery({ queryKey: ["notifications", id], queryFn: () => unwrap<Tables<"notification_log">[]>(supabase.from("notification_log").select("*").eq("owner_id", id).order("created_at", { ascending: false }).limit(500)) });
}

export async function logActivity(kind: string, description: string) {
  await supabase.from("activity_log").insert({ kind, description });
}
export function useRefresh() {
  const qc = useQueryClient();
  return (...keys: string[]) => Promise.all([...keys, "activity"].map((k) => qc.invalidateQueries({ queryKey: [k] })));
}
