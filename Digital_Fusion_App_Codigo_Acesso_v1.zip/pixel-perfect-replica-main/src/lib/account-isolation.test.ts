// @vitest-environment node
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";

const url = process.env["SUPABASE_URL"];
const key = process.env["SUPABASE_SERVICE_ROLE_KEY"];
const publishable = process.env["VITE_SUPABASE_PUBLISHABLE_KEY"];
const available = Boolean(url && key && publishable);
const ids: string[] = [];
let admin: SupabaseClient;
let a: SupabaseClient;
let b: SupabaseClient;
let clientId = "";
let paymentId = "";
let serverId = "";

describe.skipIf(!available)("live account isolation", () => {
  beforeAll(async () => {
    if (!url || !key || !publishable) throw new Error("Missing test configuration");
    const headers = (apiKey: string) => ({ fetch: (input: RequestInfo | URL, init?: RequestInit) => {
      const h = new Headers(init?.headers);
      if (h.get("Authorization") === `Bearer ${apiKey}`) h.delete("Authorization");
      h.set("apikey", apiKey);
      return fetch(input, { ...init, headers: h });
    } });
    admin = createClient(url, key, { auth: { persistSession: false }, global: headers(key) });
    const users: SupabaseClient[] = [];
    for (let i = 0; i < 2; i++) {
      const email = `isolation-${crypto.randomUUID()}@fusion.local`;
      const password = `${crypto.randomUUID()}Aa#9`;
      const result = await admin.auth.admin.createUser({ email, password, email_confirm: true });
      if (result.error || !result.data.user) throw new Error("Could not create test account");
      ids.push(result.data.user.id);
      const user = createClient(url, publishable, { auth: { persistSession: false }, global: headers(publishable) });
      const login = await user.auth.signInWithPassword({ email, password });
      if (login.error) throw new Error("Test sign-in failed");
      const defaults = await user.rpc("ensure_account_defaults");
      if (defaults.error) throw new Error(defaults.error.message);
      users.push(user);
    }
    const first = users[0], second = users[1];
    if (!first || !second) throw new Error("Missing test accounts");
    a = first; b = second;
    const server = await a.from("servers").insert({ name: "Isolation test server" }).select().single();
    if (server.error) throw new Error(server.error.message);
    serverId = server.data.id;
    const client = await a.from("clients").insert({ name: "Isolation test client", phone: "64999999999", due_date: "2027-01-15", server_id: serverId }).select().single();
    if (client.error) throw new Error(client.error.message);
    clientId = client.data.id;
    const payment = await a.from("payments").insert({ client_id: clientId, client_name: "Isolation test client", amount: 25 }).select().single();
    if (payment.error) throw new Error(payment.error.message);
    paymentId = payment.data.id;
  }, 60000);

  afterAll(async () => {
    if (!admin || !ids.length) return;
    for (const table of ["notification_log", "payments", "clients", "servers", "activity_log", "account_plans", "account_settings"]) {
      await admin.from(table).delete().in("owner_id", ids);
    }
    await admin.from("reseller_accounts").delete().in("user_id", ids);
    for (const id of ids) await admin.auth.admin.deleteUser(id);
  }, 60000);

  it("buyer can read and edit their own client", async () => {
    const result = await a.from("clients").update({ notes: "Only A" }).eq("id", clientId).select().single();
    expect(result.error).toBeNull();
    expect(result.data.notes).toBe("Only A");
  });
  it("another buyer cannot read or edit that client", async () => {
    expect((await b.from("clients").select().eq("id", clientId)).data).toEqual([]);
    expect((await b.from("clients").update({ notes: "Attack" }).eq("id", clientId).select()).data).toEqual([]);
    expect((await a.from("clients").select("notes").eq("id", clientId).single()).data?.notes).toBe("Only A");
  });
  it("another buyer cannot read or delete payments", async () => {
    expect((await b.from("payments").select().eq("id", paymentId)).data).toEqual([]);
    expect((await b.from("payments").delete().eq("id", paymentId).select()).data).toEqual([]);
    expect((await a.from("payments").select("amount").eq("id", paymentId).single()).data?.amount).toBe(25);
  });
  it("settings and plan prices are independent", async () => {
    await a.from("account_settings").update({ pix_key: "A-PIX" }).eq("owner_id", ids[0]);
    expect((await b.from("account_settings").select("pix_key").single()).data?.pix_key).toBe("");
    expect((await b.from("account_settings").update({ pix_key: "Attack" }).eq("owner_id", ids[0]).select()).data).toEqual([]);
    await a.from("account_plans").update({ price: 31 }).eq("code", "mensal");
    expect((await b.from("account_plans").select("price").eq("code", "mensal").single()).data?.price).toBe(25);
  });
  it("cannot forge ownership or link another buyer's client/server", async () => {
    expect((await b.from("clients").insert({ owner_id: ids[0], name: "Attack", phone: "64999999999", due_date: "2027-01-15" })).error).not.toBeNull();
    expect((await a.from("clients").update({ owner_id: ids[1] }).eq("id", clientId)).error).not.toBeNull();
    expect((await b.from("payments").insert({ client_id: clientId, client_name: "Attack", amount: 25 })).error).not.toBeNull();
    expect((await b.from("clients").insert({ server_id: serverId, name: "Attack", phone: "64999999999", due_date: "2027-01-15" })).error).not.toBeNull();
  });
  it("renewal refuses another buyer and records the owner's payment", async () => {
    expect((await b.rpc("renew_client", { _client_id: clientId, _method: "pix", _key: crypto.randomUUID() })).error).not.toBeNull();
    const result = await a.rpc("renew_client", { _client_id: clientId, _method: "pix", _key: crypto.randomUUID() });
    expect(result.error).toBeNull();
    expect(result.data.due_date).toBe("2027-02-15");
    expect((await b.from("payments").select().eq("id", result.data.payment_id)).data).toEqual([]);
  });
  it("platform admin role does not bypass buyer isolation", async () => {
    await admin.from("user_roles").insert({ user_id: ids[1], role: "admin" });
    expect((await b.from("clients").select().eq("id", clientId)).data).toEqual([]);
  });
  it("signup creates a profile without granting an admin role", async () => {
    expect((await a.from("profiles").select("id").eq("id", ids[0]).single()).data?.id).toBe(ids[0]);
    expect((await a.rpc("has_role", { _user_id: ids[0], _role: "admin" })).data).toBe(false);
  });
  it("buyer cannot change their own access status", async () => {
    await admin.from("reseller_accounts").insert({ user_id: ids[0], username: `test-${ids[0]}`, active: true });
    expect((await a.from("reseller_accounts").update({ active: false }).eq("user_id", ids[0]).select()).data ?? []).toEqual([]);
    expect((await a.from("reseller_accounts").select("active").eq("user_id", ids[0]).single()).data?.active).toBe(true);
  });
  it("blocking denies data access even with an existing session", async () => {
    await admin.from("reseller_accounts").update({ active: false }).eq("user_id", ids[0]);
    expect((await a.from("clients").select().eq("id", clientId)).data).toEqual([]);
    expect((await a.from("payments").select().eq("id", paymentId)).data).toEqual([]);
    expect((await a.from("account_settings").select()).data).toEqual([]);
    expect((await a.from("clients").insert({ name: "Blocked", phone: "64999999999", due_date: "2027-01-15" })).error).not.toBeNull();
    await admin.from("reseller_accounts").update({ active: true }).eq("user_id", ids[0]);
    expect((await a.from("clients").select("id").eq("id", clientId).single()).data?.id).toBe(clientId);
  });
  it("expiration blocks existing sessions and renewing validity restores access", async () => {
    const date = await admin.rpc("account_access_enabled", { _id: ids[0] });
    expect(date.data).toBe(true);
    const today = new Date(Date.now() - 3 * 3600000).toISOString().slice(0, 10);
    const expired = await admin.from("reseller_accounts").update({ expires_on: today }).eq("user_id", ids[0]);
    expect(expired.error).toBeNull();
    expect((await a.rpc("account_access_enabled", { _id: ids[0] })).data).toBe(false);
    expect((await a.from("clients").select().eq("id", clientId)).data).toEqual([]);
    expect((await a.rpc("renew_client", { _client_id: clientId, _method: "pix", _key: crypto.randomUUID() })).error).not.toBeNull();
    expect((await a.from("reseller_accounts").update({ expires_on: "2099-01-01" }).eq("user_id", ids[0]).select()).data ?? []).toEqual([]);
    expect((await admin.from("reseller_accounts").update({ expires_on: "2099-01-01" }).eq("user_id", ids[0])).error).toBeNull();
    expect((await a.rpc("account_access_enabled", { _id: ids[0] })).data).toBe(true);
    expect((await a.from("clients").select("id").eq("id", clientId).single()).data?.id).toBe(clientId);
  });
});