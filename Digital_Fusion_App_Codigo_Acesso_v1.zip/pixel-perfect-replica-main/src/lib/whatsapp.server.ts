import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { brl, fmtDate, onlyDigits } from "./business";
import { resellerAccess } from "./reseller-access";

const GATEWAY_URL = "https://connector-gateway.lovable.dev/whatsapp";

function keys() {
  const L = process.env['LOVABLE_API_KEY'], W = process.env['WHATSAPP_API_KEY'];
  if (!L || !W) throw new Error("WhatsApp não conectado (WHATSAPP_API_KEY ausente)");
  return { L, W };
}
export async function gw(path: string, init?: RequestInit) {
  const { L, W } = keys();
  const r = await fetch(`${GATEWAY_URL}${path}`, { ...init, headers: { Authorization: `Bearer ${L}`, "X-Connection-Api-Key": W, "Content-Type": "application/json", ...(init?.headers ?? {}) } });
  const text = await r.text();
  if (!r.ok) throw new Error(`Meta [${r.status}]: ${text}`);
  return JSON.parse(text || "{}");
}
export function waConfigured() { return !!process.env['WHATSAPP_API_KEY'] && !!process.env['LOVABLE_API_KEY']; }

const toPhone = (p: string) => { const d = onlyDigits(p); return d.length <= 11 ? `55${d}` : d; };

/** Envia lembrete (template aprovado) e registra no notification_log. Idempotente por (cliente, etapa, vencimento). */
export async function sendReminder(clientId: string, stage: string, ownerId: string) {
  if (!ownerId) throw new Error("Conta obrigatória");
  const { data: enabled } = await supabaseAdmin.rpc("account_access_enabled", { _id: ownerId });
  if (!enabled) throw new Error("Acesso bloqueado");
  const { data: c, error } = await supabaseAdmin.from("clients").select("*").eq("id", clientId).eq("owner_id", ownerId).single();
  if (error || !c) throw new Error("Cliente não encontrado");
  if (!c.whatsapp_consent || c.suspended) throw new Error("Cliente sem consentimento ou suspenso");
  const { data: s, error: settingsError } = await supabaseAdmin.from("account_settings").select("*").eq("owner_id", ownerId).single();
  if (settingsError || !s) throw new Error("Configurações não encontradas");
  const { data: existing } = await supabaseAdmin.from("notification_log").select("*").eq("owner_id", ownerId).eq("client_id", c.id).eq("stage", stage).eq("due_date", c.due_date).maybeSingle();
  if (existing && existing.status !== "falhou" && existing.status !== "pendente") return { skipped: true, status: existing.status };
  let logId = existing?.id;
  if (!logId) {
    const { data: ins, error: e } = await supabaseAdmin.from("notification_log").insert({ owner_id: ownerId, client_id: c.id, phone: c.phone, stage, due_date: c.due_date, status: "pendente" }).select("id").single();
    if (e) { if (e.code === "23505") return { skipped: true }; throw new Error(e.message); }
    logId = ins.id;
  }
  const attempts = (existing?.attempts ?? 0) + 1;
  try {
    const res = await gw("/messages", { method: "POST", body: JSON.stringify({
      messaging_product: "whatsapp", to: toPhone(c.phone), type: "template",
      template: { name: s?.template_name ?? "lembrete_vencimento", language: { code: s?.template_lang ?? "pt_BR" },
        components: [{ type: "body", parameters: [
          { type: "text", text: c.name }, { type: "text", text: fmtDate(c.due_date) }, { type: "text", text: brl(c.price) },
          { type: "text", text: s?.pix_key ?? "" }, { type: "text", text: s?.pix_holder ?? "" } ] }] } }) });
    const id = res?.messages?.[0]?.id ?? null;
    await supabaseAdmin.from("notification_log").update({ status: "aceito", wa_message_id: id, error: null, attempts, updated_at: new Date().toISOString() }).eq("id", logId);
    await supabaseAdmin.from("activity_log").insert({ owner_id: ownerId, kind: "whatsapp", description: `Lembrete (${stage}) enviado para ${c.name}` });
    await reconcilePendingStatuses(id);
    return { ok: true, id };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    await supabaseAdmin.from("notification_log").update({ status: "falhou", error: msg, attempts, updated_at: new Date().toISOString() }).eq("id", logId);
    await supabaseAdmin.from("activity_log").insert({ owner_id: ownerId, kind: "whatsapp_falha", description: `Falha no lembrete (${stage}) para ${c.name}` });
    return { ok: false, error: msg };
  }
}

const RANK: Record<string, number> = { pendente: 0, aceito: 1, sent: 2, delivered: 3, read: 4, failed: 5 };
const MAP: Record<string, string> = { sent: "enviada", delivered: "entregue", read: "lida", failed: "falhou" };

/** Aplica um status da Meta. Retorna false se a mensagem ainda não foi registrada. */
export async function applyStatus(st: { id: string; status: string; errors?: unknown[] }) {
  const { data: log } = await supabaseAdmin.from("notification_log").select("id,status").eq("wa_message_id", st.id).maybeSingle();
  if (!log) return false;
  const curKey = Object.entries(MAP).find(([, v]) => v === log.status)?.[0] ?? log.status;
  if ((RANK[st.status] ?? 0) <= (RANK[curKey] ?? 0) && st.status !== "failed") return true;
  await supabaseAdmin.from("notification_log").update({ status: MAP[st.status] ?? st.status, error: st.errors?.length ? JSON.stringify(st.errors) : null, updated_at: new Date().toISOString() }).eq("id", log.id);
  return true;
}

export async function processEvent(row: { id: string; event: string; payload: any }) {
  if (row.event === "whatsapp.status") {
    const statuses = row.payload?.entry?.[0]?.changes?.[0]?.value?.statuses ?? [];
    for (const st of statuses) { const ok = await applyStatus(st); if (!ok) return false; }
  }
  await supabaseAdmin.from("whatsapp_webhook_events").update({ processed_at: new Date().toISOString(), processing_error: null }).eq("id", row.id);
  return true;
}

async function reconcilePendingStatuses(msgId: string | null) {
  if (!msgId) return;
  const { data } = await supabaseAdmin.from("whatsapp_webhook_events").select("*").is("processed_at", null).eq("event", "whatsapp.status").limit(50);
  for (const r of data ?? []) if (JSON.stringify(r.payload).includes(msgId)) await processEvent(r);
}

/** Reprocessa eventos pendentes de forma limitada. */
export async function recoverEvents() {
  const { data } = await supabaseAdmin.from("whatsapp_webhook_events").select("*").is("processed_at", null).order("received_at", { ascending: true }).limit(20);
  for (const r of data ?? []) {
    const ok = await processEvent(r).catch((e) => { supabaseAdmin.from("whatsapp_webhook_events").update({ processing_error: String(e) }).eq("id", r.id); return true; });
    if (!ok && Date.now() - new Date(r.received_at).getTime() > 3 * 86400000) {
      await supabaseAdmin.from("whatsapp_webhook_events").update({ processed_at: new Date().toISOString(), processing_error: "mensagem não encontrada" }).eq("id", r.id);
    }
  }
}

export async function runDailyReminders(ownerId?: string) {
  let settingsQuery = supabaseAdmin.from("account_settings").select("owner_id").eq("reminders_enabled", true);
  if (ownerId) settingsQuery = settingsQuery.eq("owner_id", ownerId);
  const { data: settings, error: settingsError } = await settingsQuery;
  if (settingsError) throw new Error(settingsError.message);
  const { data: blocked, error: blockedError } = await supabaseAdmin.from("reseller_accounts").select("user_id,active,expires_on");
  if (blockedError) throw new Error(blockedError.message);
  const blockedIds = new Set((blocked ?? []).filter(a => !resellerAccess(a).enabled).map(a => a.user_id));
  const owners = (settings ?? []).map((s) => s.owner_id).filter(id => !blockedIds.has(id));
  if (!owners.length) return { skipped: "lembretes desativados" };
  const { toISO, reminderStage } = await import("./business");
  const now = new Date(Date.now() - 3 * 3600000); // horário de Brasília
  const today = toISO(new Date(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
  const end = toISO(new Date(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 3));
  const { data: cs, error } = await supabaseAdmin.from("clients").select("id,due_date,owner_id").in("owner_id", owners).eq("suspended", false).eq("whatsapp_consent", true).gte("due_date", today).lte("due_date", end);
  if (error) throw new Error(error.message);
  const results = [];
  for (const c of cs ?? []) { const st = reminderStage(c.due_date, today); if (st && c.owner_id) results.push(await sendReminder(c.id, st, c.owner_id)); }
  if (!ownerId) await recoverEvents();
  return { sent: results.length };
}
