import { describe, expect, it } from "vitest";
import { brasiliaDate, resellerAccess } from "./reseller-access";

describe("reseller expiration", () => {
  it("starts warnings exactly five days before expiration", () => {
    expect(resellerAccess({ active: true, expires_on: "2026-11-21" }, "2026-11-16")).toMatchObject({ warn: true, daysRemaining: 5, enabled: true });
    expect(resellerAccess({ active: true, expires_on: "2026-11-22" }, "2026-11-16").warn).toBe(false);
  });
  it("counts remaining days down to one", () => {
    expect(resellerAccess({ active: true, expires_on: "2026-11-17" }, "2026-11-16")).toMatchObject({ warn: true, daysRemaining: 1 });
  });
  it("blocks on the expiration date and thereafter", () => {
    expect(resellerAccess({ active: true, expires_on: "2026-11-16" }, "2026-11-16").enabled).toBe(false);
    expect(resellerAccess({ active: true, expires_on: "2026-11-15" }, "2026-11-16").enabled).toBe(false);
  });
  it("restores access when validity is extended unless manually blocked", () => {
    expect(resellerAccess({ active: true, expires_on: "2026-12-16" }, "2026-11-16").enabled).toBe(true);
    expect(resellerAccess({ active: false, expires_on: "2026-12-16" }, "2026-11-16").enabled).toBe(false);
  });
  it("uses the midnight boundary in Brasilia", () => {
    expect(brasiliaDate(new Date("2026-11-17T02:59:59Z"))).toBe("2026-11-16");
    expect(brasiliaDate(new Date("2026-11-17T03:00:00Z"))).toBe("2026-11-17");
  });
});