export function brasiliaDate(now = new Date()) {
  return new Date(now.getTime() - 3 * 3600000).toISOString().slice(0, 10);
}

export function resellerAccess(account: { active: boolean; expires_on: string | null } | null, today = brasiliaDate()) {
  const days = account?.expires_on ? Math.round((Date.parse(account.expires_on) - Date.parse(today)) / 86400000) : null;
  const expired = days !== null && days <= 0;
  return { enabled: account?.active !== false && !expired, expired, expiresOn: account?.expires_on ?? null, daysRemaining: days, warn: account?.active !== false && days !== null && days >= 1 && days <= 5 };
}