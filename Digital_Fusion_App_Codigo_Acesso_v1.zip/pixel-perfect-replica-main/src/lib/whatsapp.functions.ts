import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertAdmin(ctx: { supabase: any; userId: string }) {
  const { data } = await ctx.supabase.rpc("has_role", { _user_id: ctx.userId, _role: "admin" });
  if (!data) throw new Error("Acesso negado");
}

export const getWaStatus = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  await assertAdmin(context);
  const { waConfigured, gw } = await import("./whatsapp.server");
  if (!waConfigured()) return { connected: false, phone: null as string | null, error: "WhatsApp ainda não conectado" };
  try {
    const r = await gw("/phone_number?fields=display_phone_number,quality_rating,verified_name");
    return { connected: true, phone: (r.display_phone_number as string) ?? null, error: null };
  } catch (e) { return { connected: false, phone: null, error: e instanceof Error ? e.message : String(e) }; }
});

export const sendReminderNow = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ clientId: z.string().uuid(), stage: z.enum(["d3", "d1", "d0", "manual"]) }).parse(d))
  .handler(async ({ data, context }) => {
    const { data: client, error } = await context.supabase.from("clients").select("id").eq("id", data.clientId).eq("owner_id", context.userId).single();
    if (error || !client) throw new Error("Cliente não encontrado");
    const { sendReminder } = await import("./whatsapp.server");
    return sendReminder(data.clientId, data.stage, context.userId);
  });

export const runRemindersNow = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const { data: enabled } = await context.supabase.rpc("account_access_enabled", { _id: context.userId });
  if (!enabled) throw new Error("Acesso bloqueado");
  const { runDailyReminders } = await import("./whatsapp.server");
  return runDailyReminders(context.userId);
});
