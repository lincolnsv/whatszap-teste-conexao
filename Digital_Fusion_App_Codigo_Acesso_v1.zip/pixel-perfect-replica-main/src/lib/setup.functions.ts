import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export const getSetupState = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { count, error } = await supabaseAdmin.from("user_roles").select("id", { count: "exact", head: true }).eq("role", "admin");
  if (error) throw new Error(error.message);
  return { hasAdmin: (count ?? 0) > 0 };
});

export const createFirstAdmin = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) =>
    z.object({ username: z.string().trim().min(3).max(40).regex(/^[a-zA-Z0-9._-]+$/), password: z.string().min(8).max(100) }).parse(d),
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { count, error: countError } = await supabaseAdmin.from("user_roles").select("id", { count: "exact", head: true }).eq("role", "admin");
    if (countError) throw new Error("Não foi possível verificar o administrador.");
    if ((count ?? 0) > 0) throw new Error("O administrador já foi criado.");
    const email = `${data.username.toLowerCase()}@fusion.local`;
    const { data: u, error } = await supabaseAdmin.auth.admin.createUser({ email, password: data.password, email_confirm: true, user_metadata: { username: data.username } });
    if (error || !u.user) throw new Error(error?.message ?? "Falha ao criar usuário");
    const { error: e2 } = await supabaseAdmin.from("user_roles").insert({ user_id: u.user.id, role: "admin" });
    if (e2) throw new Error(e2.message);
    await supabaseAdmin.from("activity_log").insert({ owner_id: u.user.id, kind: "config", description: `Administrador "${data.username}" criado` });
    return { ok: true };
  });
