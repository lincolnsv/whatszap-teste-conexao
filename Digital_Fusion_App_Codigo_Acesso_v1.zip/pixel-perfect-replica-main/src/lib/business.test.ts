import { describe, it, expect } from "vitest";
import { computeRenewal, clientStatus, reminderStage, addMonths } from "./business";

describe("renovação", () => {
  it("cliente vencido renova a partir de hoje", () => {
    expect(computeRenewal("2026-10-01", 1, "2026-11-12")).toBe("2026-12-12");
  });
  it("cliente ativo renova a partir do vencimento atual", () => {
    expect(computeRenewal("2026-11-20", 3, "2026-11-12")).toBe("2027-02-20");
  });
  it("anual acrescenta 12 meses", () => { expect(computeRenewal("2026-11-20", 12, "2026-11-12")).toBe("2027-11-20"); });
  it("fim de mês não estoura", () => { expect(addMonths("2026-01-31", 1)).toBe("2026-02-28"); });
});
describe("status", () => {
  it("vence em 3 dias = vencendo", () => expect(clientStatus({ due_date: "2026-11-15", suspended: false }, "2026-11-12")).toBe("vencendo"));
  it("passado = vencido", () => expect(clientStatus({ due_date: "2026-11-11", suspended: false }, "2026-11-12")).toBe("vencido"));
  it("suspenso prevalece", () => expect(clientStatus({ due_date: "2027-01-01", suspended: true }, "2026-11-12")).toBe("suspenso"));
});
describe("lembretes", () => {
  it("3 dias, 1 dia e no dia", () => {
    expect(reminderStage("2026-11-15", "2026-11-12")).toBe("d3");
    expect(reminderStage("2026-11-13", "2026-11-12")).toBe("d1");
    expect(reminderStage("2026-11-12", "2026-11-12")).toBe("d0");
    expect(reminderStage("2026-11-14", "2026-11-12")).toBeNull();
  });
});
