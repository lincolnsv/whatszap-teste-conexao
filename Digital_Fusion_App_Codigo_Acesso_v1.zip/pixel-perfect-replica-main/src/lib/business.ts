// Regras de negócio puras (datas em YYYY-MM-DD, fuso local).
export type ClientStatus = "ativo" | "vencendo" | "vencido" | "suspenso";

export const PLAN_MONTHS: Record<string, number> = { mensal: 1, trimestral: 3, semestral: 6, anual: 12 };

export function toISO(d: Date) {
  const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, "0"), dd = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${dd}`;
}
export function parseISO(s: string) { const [y = 1970, m = 1, d = 1] = s.split("-").map(Number); return new Date(y, m - 1, d); }
export function daysBetween(fromISO: string, toISOStr: string) {
  return Math.round((parseISO(toISOStr).getTime() - parseISO(fromISO).getTime()) / 86400000);
}
export function addMonths(iso: string, months: number) {
  const d = parseISO(iso); const day = d.getDate();
  const r = new Date(d.getFullYear(), d.getMonth() + months, 1);
  const last = new Date(r.getFullYear(), r.getMonth() + 1, 0).getDate();
  r.setDate(Math.min(day, last));
  return toISO(r);
}
/** Vencido: renova a partir de hoje. Ativo: a partir do vencimento atual. */
export function computeRenewal(dueISO: string, months: number, todayISO: string) {
  const base = dueISO < todayISO ? todayISO : dueISO;
  return addMonths(base, months);
}
export function clientStatus(c: { due_date: string; suspended: boolean }, todayISO: string): ClientStatus {
  if (c.suspended) return "suspenso";
  const diff = daysBetween(todayISO, c.due_date);
  if (diff < 0) return "vencido";
  if (diff <= 3) return "vencendo";
  return "ativo";
}
/** Etapa do lembrete conforme dias até o vencimento. */
export function reminderStage(dueISO: string, todayISO: string): "d3" | "d1" | "d0" | null {
  const diff = daysBetween(todayISO, dueISO);
  return diff === 3 ? "d3" : diff === 1 ? "d1" : diff === 0 ? "d0" : null;
}
export const brl = (v: number | string) => Number(v).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
export const fmtDate = (iso?: string | null) => (iso ? iso.slice(0, 10).split("-").reverse().join("/") : "—");
export const fmtDateTime = (s: string) => new Date(s).toLocaleString("pt-BR");
export const todayISO = () => toISO(new Date());
export const onlyDigits = (s: string) => s.replace(/\D/g, "");
export const STATUS_LABEL: Record<ClientStatus, string> = { ativo: "Ativo", vencendo: "Vencendo", vencido: "Vencido", suspenso: "Suspenso" };
export const METHOD_LABEL: Record<string, string> = { pix: "Pix", dinheiro: "Dinheiro", cartao: "Cartão", outros: "Outros" };
export const usernameToEmail = (u: string) => `${u.trim().toLowerCase().replace(/[^a-z0-9._-]/g, "")}@fusion.local`;
