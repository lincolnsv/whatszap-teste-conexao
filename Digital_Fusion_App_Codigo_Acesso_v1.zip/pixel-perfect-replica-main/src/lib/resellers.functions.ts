import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";
import { resellerAccess } from "./reseller-access";

async function authorize(context: { supabase: SupabaseClient<Database>; userId: string }) {
  const { data, error } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
  if (error || !data) throw new Error("Acesso exclusivo do superadministrador.");
}
const expiration = z.string().date("Informe uma data de expiração válida.");
const registration = z.object({ name: z.string().trim().min(2).max(120), phone: z.string().trim().refine(v => v.replace(/\D/g, "").length >= 10, "Informe telefone com DDD."), username: z.string().trim().min(3).max(40).regex(/^[a-zA-Z0-9._-]+$/).transform(v => v.toLowerCase()), password: z.string().min(8).max(100), expiresOn: expiration });
export const getOwnAccess = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  const { data, error } = await context.supabase.from("reseller_accounts").select("active,expires_on").eq("user_id", context.userId).maybeSingle();
  if (error) throw new Error("Não foi possível verificar a validade do acesso.");
  return resellerAccess(data);
});
export const listResellers = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(async ({ context }) => {
  await authorize(context);
  const { data: accounts, error } = await context.supabase.from("reseller_accounts").select("*").order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  const { data: profiles, error: pe } = await context.supabase.from("profiles").select("*");
  if (pe) throw new Error(pe.message);
  return (accounts ?? []).map(a => ({ ...a, name: profiles?.find(p => p.id === a.user_id)?.name ?? "", phone: profiles?.find(p => p.id === a.user_id)?.phone ?? "" }));
});
export const createReseller = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d: unknown) => registration.parse(d)).handler(async ({ context, data }) => {
  await authorize(context);
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  // Provisioned credentials do not use email signup: username addresses cannot receive email.
  const { data: created, error } = await supabaseAdmin.auth.admin.createUser({ email: `${data.username}@fusion.local`, password: data.password, email_confirm: true });
  if (error || !created.user) throw new Error(/already|registered/i.test(error?.message ?? "") ? "Este usuário já está cadastrado." : "Não foi possível criar o acesso. Use uma senha forte e um usuário disponível.");
  const id = created.user.id;
  try {
    const profile = await supabaseAdmin.from("profiles").update({ name: data.name, phone: data.phone }).eq("id", id);
    if (profile.error) throw profile.error;
    const account = await supabaseAdmin.from("reseller_accounts").insert({ user_id: id, username: data.username, expires_on: data.expiresOn });
    if (account.error) throw account.error;
  } catch {
    await supabaseAdmin.from("reseller_accounts").delete().eq("user_id", id);
    await supabaseAdmin.auth.admin.deleteUser(id);
    throw new Error("Não foi possível salvar o revendedor.");
  }
  return { ok: true };
});
export const updateReseller = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d: unknown) => z.object({ userId: z.string().uuid(), name: z.string().trim().min(2).max(120), phone: registration.shape.phone, active: z.boolean(), expiresOn: expiration, password: z.string().min(8).max(100).optional() }).parse(d)).handler(async ({ context, data }) => {
  await authorize(context);
  if (data.userId === context.userId) throw new Error("Não é permitido alterar seu próprio acesso por aqui.");
  const { data: account, error } = await context.supabase.from("reseller_accounts").select("user_id").eq("user_id", data.userId).single();
  if (error || !account) throw new Error("Revendedor não encontrado.");
  const { data: targetAdmin } = await context.supabase.rpc("has_role", { _user_id: data.userId, _role: "admin" });
  if (targetAdmin) throw new Error("Este acesso é de um superadministrador.");
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  if (data.password) {
    const changed = await supabaseAdmin.auth.admin.updateUserById(data.userId, { password: data.password });
    if (changed.error) throw new Error("Não foi possível trocar a senha. Use uma senha forte.");
  }
  const profile = await supabaseAdmin.from("profiles").update({ name: data.name, phone: data.phone }).eq("id", data.userId);
  if (profile.error) throw new Error("Não foi possível salvar os dados.");
  const result = await supabaseAdmin.from("reseller_accounts").update({ active: data.active, expires_on: data.expiresOn }).eq("user_id", data.userId);
  if (result.error) throw new Error("Não foi possível alterar o acesso.");
  return { ok: true };
});