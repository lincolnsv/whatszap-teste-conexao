import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/health")({
  server: {
    handlers: {
      GET: async () => {
        let database = false;
        try {
          const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
          const { error } = await supabaseAdmin.from("settings").select("id").limit(1);
          database = !error;
        } catch { database = false; }
        return Response.json({ status: "ok", database, whatsapp: !!process.env['WHATSAPP_API_KEY'], time: new Date().toISOString() });
      },
    },
  },
});
