import { createFileRoute } from "@tanstack/react-router";
import { verifyWebhookRequest } from "@lovable.dev/webhooks-js";

export const Route = createFileRoute("/api/public/whatsapp/webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const secret = process.env['WHATSAPP_API_KEY'];
        if (!secret) return new Response("not configured", { status: 503 });
        let payload: unknown;
        try {
          const v = await verifyWebhookRequest({ req: request, secret, maxBodyBytes: 4 * 1024 * 1024 });
          payload = v.payload;
        } catch { return new Response("unauthorized", { status: 401 }); }
        const deliveryId = request.headers.get("X-Lovable-Delivery");
        const event = request.headers.get("X-Lovable-Event");
        if (!deliveryId || !event) return new Response("missing headers", { status: 400 });
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const { processEvent } = await import("@/lib/whatsapp.server");
        const { error } = await supabaseAdmin.from("whatsapp_webhook_events").upsert({ delivery_id: deliveryId, event, payload: payload as any }, { onConflict: "delivery_id", ignoreDuplicates: true });
        if (error) return new Response("db error", { status: 500 });
        const { data: row } = await supabaseAdmin.from("whatsapp_webhook_events").select("*").eq("delivery_id", deliveryId).single();
        if (!row) return new Response("db error", { status: 500 });
        if (row.processed_at) return new Response("ok");
        try { await processEvent(row); } catch (e) {
          await supabaseAdmin.from("whatsapp_webhook_events").update({ processing_error: String(e) }).eq("id", row.id);
          return new Response("processing error", { status: 500 });
        }
        return new Response("ok"); // status sem mensagem correspondente fica pendente e é reconciliado depois
      },
    },
  },
});
