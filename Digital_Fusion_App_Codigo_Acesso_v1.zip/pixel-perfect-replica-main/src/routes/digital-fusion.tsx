import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { ArrowRight, CalendarDays, CheckCircle2, CircleAlert, KeyRound, LogOut, ShieldCheck, Smartphone, Sparkles, Wallet } from "lucide-react";
import { toast } from "sonner";
import { customerSupabase } from "@/integrations/supabase/customer-client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/digital-fusion")({
  head: () => ({
    meta: [
      { title: "Digital Fusion — Área do Cliente" },
      { name: "description", content: "Consulte seu plano e acompanhe suas renovações no Digital Fusion." },
      { name: "theme-color", content: "#101827" },
    ],
    links: [{ rel: "manifest", href: "/manifest.webmanifest" }],
  }),
  component: DigitalFusion,
});

type InstallPromptEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: "accepted" | "dismissed" }> };

type CustomerProfile = {
  name: string;
  plan: string;
  price: number;
  due_date: string;
  suspended: boolean;
  status: "ativo" | "vencendo" | "vencido" | "suspenso";
};

function formatDate(value: string) {
  if (!value) return "—";
  return new Intl.DateTimeFormat("pt-BR", { dateStyle: "long", timeZone: "UTC" }).format(new Date(`${value}T12:00:00Z`));
}

function money(value: number) {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(value || 0);
}

function DigitalFusion() {
  const [code, setCode] = useState("");
  const [profile, setProfile] = useState<CustomerProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);

  const loadProfile = useCallback(async () => {
    const { data: sessionData } = await customerSupabase.auth.getSession();
    if (!sessionData.session) { setLoading(false); return; }
    const { data, error: profileError } = await customerSupabase.rpc("get_customer_app_profile" as never);
    if (profileError) {
      setError("Não foi possível carregar sua conta. Se você ainda não ativou o aplicativo, informe o código recebido do seu revendedor.");
      setLoading(false);
      return;
    }
    setProfile((data as unknown as CustomerProfile | null) ?? null);
    setLoading(false);
  }, []);

  useEffect(() => {
    const standalone = window.matchMedia("(display-mode: standalone)").matches || ("standalone" in navigator && (navigator as Navigator & { standalone?: boolean }).standalone === true);
    setIsInstalled(standalone);
    const onInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    const onInstalled = () => { setIsInstalled(true); setInstallPrompt(null); };
    window.addEventListener("beforeinstallprompt", onInstallPrompt);
    window.addEventListener("appinstalled", onInstalled);
    void loadProfile();
    if ("serviceWorker" in navigator) void navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    return () => {
      window.removeEventListener("beforeinstallprompt", onInstallPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, [loadProfile]);

  async function installApp() {
    if (!installPrompt) return;
    await installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    if (choice?.outcome === "accepted") setIsInstalled(true);
    setInstallPrompt(null);
  }

  async function activate(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      const { data: sessionData, error: sessionError } = await customerSupabase.auth.getSession();
      if (!sessionData.session) {
        const { error: anonError } = await customerSupabase.auth.signInAnonymously();
        if (anonError) {
          throw new Error("Não foi possível iniciar o aplicativo. A autenticação anônima precisa estar habilitada no Supabase.");
        }
      }
      const { error: activationError } = await customerSupabase.rpc("activate_customer_app_code" as never, { _code: code.trim().toUpperCase() } as never);
      if (activationError) throw activationError;
      const { data, error: profileError } = await customerSupabase.rpc("get_customer_app_profile" as never);
      if (profileError || !data) throw new Error("Código ativado, mas não foi possível carregar o cadastro. Atualize a página.");
      setProfile(data as unknown as CustomerProfile);
      toast.success("Aplicativo ativado com sucesso!");
    } catch (err) {
      const message = err instanceof Error ? err.message : "Não foi possível ativar o código.";
      setError(message);
    } finally {
      setBusy(false);
    }
  }

  async function logout() {
    await customerSupabase.auth.signOut();
    setProfile(null);
    setCode("");
    setError(null);
  }

  if (loading) return <main className="flex min-h-screen items-center justify-center bg-[#101827] text-white">Carregando Digital Fusion…</main>;

  const installRequired = !isInstalled && !import.meta.env.DEV;

  return (
    <main className="min-h-screen bg-[#101827] px-4 py-8 text-white">
      <div className="mx-auto flex w-full max-w-md flex-col gap-6">
        <header className="flex items-center gap-3 pt-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-400 text-slate-950"><Sparkles className="h-6 w-6" /></div>
          <div><p className="text-xl font-bold tracking-tight">Digital Fusion</p><p className="text-sm text-slate-400">Seu acesso, sempre à mão</p></div>
        </header>

        {installRequired ? (
          <section className="mt-8 rounded-3xl border border-white/10 bg-white/[0.06] p-6 shadow-2xl">
            <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-400 text-slate-950"><Smartphone className="h-7 w-7" /></div>
            <h1 className="text-2xl font-bold">Instale o Digital Fusion</h1>
            <p className="mt-2 text-sm leading-6 text-slate-300">Para acessar sua conta, primeiro adicione o Digital Fusion à tela inicial do celular.</p>
            {installPrompt ? (
              <Button onClick={() => void installApp()} className="mt-6 h-12 w-full bg-emerald-400 font-semibold text-slate-950 hover:bg-emerald-300">Instalar aplicativo</Button>
            ) : (
              <div className="mt-5 space-y-3 rounded-2xl bg-slate-950/60 p-4 text-sm leading-6 text-slate-300">
                <p><strong className="text-white">Android:</strong> abra o menu do navegador (⋮) e escolha “Instalar aplicativo” ou “Adicionar à tela inicial”.</p>
                <p><strong className="text-white">iPhone:</strong> toque em Compartilhar e depois em “Adicionar à Tela de Início”.</p>
                <p className="text-xs text-slate-500">Depois de instalar, abra o Digital Fusion pelo ícone criado na tela inicial.</p>
              </div>
            )}
          </section>
        ) : !profile ? (
          <section className="mt-8 rounded-3xl border border-white/10 bg-white/[0.06] p-6 shadow-2xl">
            <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10"><KeyRound className="h-6 w-6 text-emerald-300" /></div>
            <h1 className="text-2xl font-bold">Ative seu aplicativo</h1>
            <p className="mt-2 text-sm leading-6 text-slate-300">Digite o código de acesso fornecido pelo seu revendedor Digital Fusion. O código pode ser usado uma única vez.</p>
            <form onSubmit={activate} className="mt-6 space-y-4">
              <label className="block text-sm font-medium text-slate-200" htmlFor="activation-code">Código de acesso</label>
              <Input id="activation-code" autoCapitalize="characters" autoComplete="one-time-code" placeholder="DF-XXXXXXXX" value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} required maxLength={15} className="h-14 border-white/15 bg-slate-950/70 text-center text-xl font-bold tracking-[0.18em] text-white placeholder:text-slate-600" />
              {error && <p role="alert" className="flex items-start gap-2 text-sm text-rose-300"><CircleAlert className="mt-0.5 h-4 w-4 shrink-0" />{error}</p>}
              <Button type="submit" disabled={busy || code.trim().length < 8} className="h-12 w-full bg-emerald-400 font-semibold text-slate-950 hover:bg-emerald-300">{busy ? "Verificando código…" : <>Ativar meu aplicativo <ArrowRight className="ml-2 h-4 w-4" /></>}</Button>
            </form>
            <div className="mt-6 flex items-start gap-2 rounded-2xl bg-slate-950/60 p-3 text-xs leading-5 text-slate-400"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-300" />Seu código é individual e vincula este aparelho ao cadastro feito pelo seu revendedor.</div>
          </section>
        ) : (
          <>
            <section className="rounded-3xl bg-gradient-to-br from-emerald-400 to-teal-600 p-6 text-slate-950 shadow-xl">
              <p className="text-sm font-medium text-slate-900/70">Bem-vindo(a),</p>
              <h1 className="mt-1 text-2xl font-bold">{profile.name}</h1>
              <p className="mt-5 text-sm text-slate-900/70">Seu plano</p>
              <p className="text-xl font-bold">{profile.plan}</p>
              <p className="mt-1 text-sm font-semibold">{money(profile.price)} / período</p>
            </section>
            <section className="rounded-3xl border border-white/10 bg-white/[0.06] p-5">
              <div className="flex items-center gap-3"><CalendarDays className="h-5 w-5 text-emerald-300" /><p className="font-semibold">Vencimento do seu plano</p></div>
              <p className="mt-4 text-2xl font-bold">{formatDate(profile.due_date)}</p>
              <p className={`mt-2 inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-semibold ${profile.status === "ativo" ? "bg-emerald-400/15 text-emerald-300" : "bg-amber-400/15 text-amber-200"}`}><CheckCircle2 className="h-3.5 w-3.5" />{profile.status === "ativo" ? "Plano ativo" : profile.status === "vencendo" ? "Seu plano está vencendo" : profile.status === "vencido" ? "Plano vencido" : "Acesso suspenso"}</p>
            </section>
            <section className="rounded-3xl border border-white/10 bg-white/[0.06] p-5">
              <div className="flex items-center gap-3"><Wallet className="h-5 w-5 text-emerald-300" /><p className="font-semibold">Renovação</p></div>
              <p className="mt-2 text-sm leading-6 text-slate-300">As opções de renovação e ofertas especiais aparecerão aqui quando forem liberadas pelo seu revendedor.</p>
              <Button disabled className="mt-4 w-full bg-white/10 text-slate-400"><Smartphone className="mr-2 h-4 w-4" />Renovação em breve</Button>
            </section>
            <Button variant="ghost" onClick={logout} className="text-slate-400 hover:text-white"><LogOut className="mr-2 h-4 w-4" />Sair deste aparelho</Button>
          </>
        )}
        <footer className="pb-6 text-center text-xs text-slate-500">Digital Fusion • Área segura do cliente</footer>
      </div>
    </main>
  );
}
