import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Plus, Search, Pencil, Trash2, RefreshCw, History, Eye, EyeOff, KeyRound, Copy, ExternalLink } from "lucide-react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { PageHeader, StatusBadge, Loading, ErrorBox, Empty, Panel } from "@/components/app/ui";
import { ClientDialog, RenewDialog, HistoryDialog } from "@/components/app/dialogs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { type Client, useClients, useServers, usePlans, logActivity, useRefresh } from "@/lib/data";
import { brl, clientStatus, fmtDate, onlyDigits, todayISO } from "@/lib/business";

export const Route = createFileRoute("/_authenticated/clientes")({
  validateSearch: z.object({ q: z.string().optional(), edit: z.string().optional() }),
  head: () => ({ meta: [{ title: "Clientes — Fusion Gestão Pro" }, { name: "description", content: "Cadastro e gestão de clientes e assinaturas." }, { property: "og:title", content: "Clientes — Fusion Gestão Pro" }, { property: "og:description", content: "Cadastro e gestão de clientes e assinaturas." }] }),
  component: Clientes,
});

function Clientes() {
  const search = Route.useSearch();
  const { data, isLoading, error } = useClients();
  const { data: servers = [] } = useServers();
  const { data: plans = [] } = usePlans();
  const refresh = useRefresh();
  const [q, setQ] = useState(search.q ?? "");
  const [server, setServer] = useState("all");
  const [status, setStatus] = useState("all");
  const [editing, setEditing] = useState<Client | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [renew, setRenew] = useState<Client | null>(null);
  const [hist, setHist] = useState<Client | null>(null);
  const [del, setDel] = useState<Client | null>(null);
  const [reveal, setReveal] = useState<string | null>(null);
  const [codeClient, setCodeClient] = useState<Client | null>(null);
  const [issuedCode, setIssuedCode] = useState<string | null>(null);
  const [issuingCode, setIssuingCode] = useState(false);
  const today = todayISO();
  const srvName = (id: string | null) => servers.find((s) => s.id === id)?.name ?? "—";
  const planLabel = (c: string) => plans.find((p) => p.code === c)?.label ?? c;

  const rows = useMemo(() => {
    const term = q.trim().toLowerCase(), digits = onlyDigits(q);
    return (data ?? []).filter((c) =>
      (!term || c.name.toLowerCase().includes(term) || (digits.length > 0 && onlyDigits(c.phone).includes(digits))) &&
      (server === "all" || c.server_id === server) && (status === "all" || clientStatus(c, today) === status));
  }, [data, q, server, status, today]);

  // abrir edição via ?edit=id
  useEffect(() => { if (search.edit && data) { const c = data.find((x) => x.id === search.edit); if (c) { setEditing(c); setFormOpen(true); } } }, [search.edit, data]);

  async function generateAppCode(client: Client) {
    setCodeClient(client);
    setIssuedCode(null);
    setIssuingCode(true);
    const { data, error } = await (supabase as any).rpc("create_customer_app_code", { _client_id: client.id });
    setIssuingCode(false);
    if (error) {
      toast.error(error.message || "Não foi possível gerar o código do aplicativo.");
      return;
    }
    setIssuedCode(String(data));
    toast.success("Código do Digital Fusion gerado.");
  }

  async function copyAppLink() {
    try {
      await navigator.clipboard.writeText(`${window.location.origin}/digital-fusion`);
      toast.success("Link do aplicativo copiado!");
    } catch {
      toast.error("Não foi possível copiar o link.");
    }
  }

  async function copyAppCode() {
    if (!issuedCode) return;
    try {
      await navigator.clipboard.writeText(issuedCode);
      toast.success("Código copiado!");
    } catch {
      toast.error("Não foi possível copiar. Selecione e copie o código manualmente.");
    }
  }

  async function remove() {
    if (!del) return;
    const { error } = await supabase.from("clients").delete().eq("id", del.id);
    if (error) return void toast.error(error.message);
    await logActivity("cliente_excluido", `Cliente excluído: ${del.name}`);
    toast.success("Cliente excluído"); setDel(null); refresh("clients");
  }

  return (
    <>
      <PageHeader title="Clientes" subtitle={`${data?.length ?? 0} clientes cadastrados`} actions={<Button onClick={() => { setEditing(null); setFormOpen(true); }}><Plus className="h-4 w-4" />Novo cliente</Button>} />
      <Panel>
        <div className="mb-4 flex flex-col gap-2 md:flex-row">
          <div className="relative flex-1"><Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" /><Input className="pl-9" placeholder="Buscar por nome ou telefone" value={q} onChange={(e) => setQ(e.target.value)} /></div>
          <Select value={server} onValueChange={setServer}><SelectTrigger className="md:w-48"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todos os servidores</SelectItem>{servers.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent></Select>
          <Select value={status} onValueChange={setStatus}><SelectTrigger className="md:w-40"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todas as situações</SelectItem><SelectItem value="ativo">Ativo</SelectItem><SelectItem value="vencendo">Vencendo</SelectItem><SelectItem value="vencido">Vencido</SelectItem><SelectItem value="suspenso">Suspenso</SelectItem></SelectContent></Select>
        </div>
        {isLoading ? <Loading /> : error ? <ErrorBox error={error} /> : rows.length === 0 ? <Empty /> : (
          <div className="overflow-x-auto"><Table>
            <TableHeader><TableRow><TableHead>Cliente</TableHead><TableHead>Servidor</TableHead><TableHead>Acesso</TableHead><TableHead>Plano</TableHead><TableHead>Vencimento</TableHead><TableHead>Situação</TableHead><TableHead className="text-right">Ações</TableHead></TableRow></TableHeader>
            <TableBody>{rows.map((c) => (
              <TableRow key={c.id}>
                <TableCell><p className="font-medium">{c.name}</p><p className="text-xs text-muted-foreground">{c.phone}</p></TableCell>
                <TableCell>{srvName(c.server_id)}</TableCell>
                <TableCell className="text-xs">{c.access_user ?? "—"}{c.access_password && <div className="flex items-center gap-1 text-muted-foreground">{reveal === c.id ? c.access_password : "••••••"}<button aria-label="Mostrar senha" onClick={() => setReveal(reveal === c.id ? null : c.id)}>{reveal === c.id ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}</button></div>}</TableCell>
                <TableCell>{planLabel(c.plan)}<p className="text-xs text-muted-foreground">{brl(c.price)}</p></TableCell>
                <TableCell>{fmtDate(c.due_date)}</TableCell>
                <TableCell><StatusBadge status={clientStatus(c, today)} /></TableCell>
                <TableCell className="text-right whitespace-nowrap">
                  <Button size="sm" variant="outline" onClick={() => setRenew(c)}><RefreshCw className="h-3.5 w-3.5" />Renovar</Button>
                  <Button size="icon" variant="ghost" aria-label="Gerar código do Digital Fusion" title="Código do aplicativo" onClick={() => void generateAppCode(c)}><KeyRound className="h-4 w-4" /></Button>
                  <Button size="icon" variant="ghost" aria-label="Histórico" onClick={() => setHist(c)}><History className="h-4 w-4" /></Button>
                  <Button size="icon" variant="ghost" aria-label="Editar" onClick={() => { setEditing(c); setFormOpen(true); }}><Pencil className="h-4 w-4" /></Button>
                  <Button size="icon" variant="ghost" aria-label="Excluir" onClick={() => setDel(c)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                </TableCell>
              </TableRow>))}
            </TableBody>
          </Table></div>
        )}
      </Panel>
      <Dialog open={!!codeClient} onOpenChange={(open) => { if (!open) { setCodeClient(null); setIssuedCode(null); } }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Código do Digital Fusion</DialogTitle>
            <DialogDescription>
              {codeClient ? `Código de acesso para ${codeClient.name}. Ele é válido por 7 dias e pode ser usado uma única vez.` : ""}
            </DialogDescription>
          </DialogHeader>
          {issuingCode ? <p className="py-6 text-center text-sm text-muted-foreground">Gerando código seguro…</p> : issuedCode ? (
            <div className="space-y-3">
              <div className="rounded-xl border bg-muted p-4 text-center text-2xl font-bold tracking-[0.2em]">{issuedCode}</div>
              <p className="text-sm text-muted-foreground">Envie esse código ao cliente. Por segurança, ele só será exibido agora. Gerar outro código invalidará o vínculo anterior deste cliente.</p>
              <Button className="w-full" onClick={() => void copyAppCode()}><Copy className="mr-2 h-4 w-4" />Copiar código</Button>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">Não foi possível gerar o código. Confira a instalação da migração 0005 no Supabase e tente novamente.</p>
          )}
          {issuedCode && <Button variant="outline" className="w-full" onClick={() => void copyAppLink()}><ExternalLink className="mr-2 h-4 w-4" />Copiar link do aplicativo</Button>}
          <DialogFooter><Button variant="outline" onClick={() => { setCodeClient(null); setIssuedCode(null); }}>Fechar</Button></DialogFooter>
        </DialogContent>
      </Dialog>
      <ClientDialog open={formOpen} onOpenChange={(o) => { setFormOpen(o); if (!o) setEditing(null); }} client={editing} />
      <RenewDialog client={renew} onOpenChange={(o) => !o && setRenew(null)} />
      <HistoryDialog client={hist} onOpenChange={(o) => !o && setHist(null)} />
      <AlertDialog open={!!del} onOpenChange={(o) => !o && setDel(null)}>
        <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Excluir {del?.name}?</AlertDialogTitle><AlertDialogDescription>Os pagamentos já registrados serão mantidos no histórico financeiro.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Cancelar</AlertDialogCancel><AlertDialogAction onClick={remove}>Excluir</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
      </AlertDialog>
    </>
  );
}
