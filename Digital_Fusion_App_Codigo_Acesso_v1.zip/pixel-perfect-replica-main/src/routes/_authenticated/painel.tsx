import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import { Users, UserCheck, UserX, CalendarClock, AlarmClock, Server, Wallet, CheckCircle2, Clock, RefreshCw } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Cell, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis, Legend } from "recharts";
import { PageHeader, StatCard, Panel, Loading, ErrorBox, Empty } from "@/components/app/ui";
import { useClients, usePayments, useServers, usePlans, useActivity } from "@/lib/data";
import { brl, clientStatus, daysBetween, fmtDateTime, todayISO } from "@/lib/business";

export const Route = createFileRoute("/_authenticated/painel")({
  head: () => ({ meta: [{ title: "Visão geral — Fusion Gestão Pro" }, { name: "description", content: "Indicadores de clientes, vencimentos e faturamento." }, { property: "og:title", content: "Visão geral — Fusion Gestão Pro" }, { property: "og:description", content: "Indicadores de clientes, vencimentos e faturamento." }] }),
  component: Painel,
});

const COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];
const MONTHS = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];

function Painel() {
  const c = useClients(), p = usePayments(), s = useServers(), pl = usePlans(), a = useActivity();
  const today = todayISO();
  const stats = useMemo(() => {
    const clients = c.data ?? [], pays = p.data ?? [];
    const st = clients.map((x) => ({ x, s: clientStatus(x, today), d: daysBetween(today, x.due_date) }));
    const month = today.slice(0, 7);
    const confirmed = pays.filter((x) => x.status === "confirmado");
    const now = new Date();
    const last12 = Array.from({ length: 12 }, (_, i) => { const d = new Date(now.getFullYear(), now.getMonth() - 11 + i, 1); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`; });
    return {
      total: clients.length,
      ativos: st.filter((y) => y.s === "ativo" || y.s === "vencendo").length,
      vencidos: st.filter((y) => y.s === "vencido").length,
      hoje: st.filter((y) => !y.x.suspended && y.d === 0).length,
      tres: st.filter((y) => !y.x.suspended && y.d > 0 && y.d <= 3).length,
      mes: confirmed.filter((x) => x.paid_at.startsWith(month)).reduce((t, x) => t + Number(x.amount), 0),
      recebidos: confirmed.length,
      pendentes: pays.filter((x) => x.status === "pendente").length,
      renov: pays.filter((x) => x.is_renewal).length,
      revenue: last12.map((m) => ({ mes: MONTHS[Number(m.slice(5)) - 1] + "/" + m.slice(2, 4), valor: confirmed.filter((x) => x.paid_at.startsWith(m)).reduce((t, x) => t + Number(x.amount), 0) })),
      growth: last12.map((m) => ({ mes: MONTHS[Number(m.slice(5)) - 1] + "/" + m.slice(2, 4), clientes: clients.filter((x) => x.signup_date.slice(0, 7) <= m).length })),
      status: [{ name: "Ativos", value: st.filter((y) => y.s === "ativo").length }, { name: "Vencendo", value: st.filter((y) => y.s === "vencendo").length }, { name: "Vencidos", value: st.filter((y) => y.s === "vencido").length }, { name: "Suspensos", value: st.filter((y) => y.s === "suspenso").length }],
      plans: (pl.data ?? []).map((q) => ({ name: q.label, value: clients.filter((x) => x.plan === q.code).length })),
    };
  }, [c.data, p.data, pl.data, today]);

  if (c.isLoading || p.isLoading) return <Loading />;
  if (c.error || p.error) return <ErrorBox error={c.error || p.error} />;
  return (
    <>
      <PageHeader title="Visão geral" subtitle="Resumo atualizado do seu negócio." />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
        <StatCard label="Clientes" value={stats.total} icon={Users} />
        <StatCard label="Ativos" value={stats.ativos} icon={UserCheck} tone="success" />
        <StatCard label="Vencidos" value={stats.vencidos} icon={UserX} tone="danger" />
        <StatCard label="Vencem hoje" value={stats.hoje} icon={AlarmClock} tone="warning" />
        <StatCard label="Próximos 3 dias" value={stats.tres} icon={CalendarClock} tone="warning" />
        <StatCard label="Servidores" value={s.data?.length ?? 0} icon={Server} tone="info" />
        <StatCard label="Faturamento do mês" value={brl(stats.mes)} icon={Wallet} tone="success" />
        <StatCard label="Pagamentos recebidos" value={stats.recebidos} icon={CheckCircle2} tone="success" />
        <StatCard label="Pagamentos pendentes" value={stats.pendentes} icon={Clock} tone="warning" />
        <StatCard label="Renovações" value={stats.renov} icon={RefreshCw} />
      </div>
      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Panel title="Faturamento mensal"><div className="h-64"><ResponsiveContainer><BarChart data={stats.revenue}><CartesianGrid strokeDasharray="3 3" stroke="var(--border)" /><XAxis dataKey="mes" fontSize={11} /><YAxis fontSize={11} /><Tooltip formatter={(v: number) => brl(v)} /><Bar dataKey="valor" fill="var(--chart-1)" radius={[6, 6, 0, 0]} /></BarChart></ResponsiveContainer></div></Panel>
        <Panel title="Crescimento de clientes"><div className="h-64"><ResponsiveContainer><LineChart data={stats.growth}><CartesianGrid strokeDasharray="3 3" stroke="var(--border)" /><XAxis dataKey="mes" fontSize={11} /><YAxis fontSize={11} allowDecimals={false} /><Tooltip /><Line dataKey="clientes" stroke="var(--chart-2)" strokeWidth={2.5} dot={false} /></LineChart></ResponsiveContainer></div></Panel>
        <Panel title="Situação dos clientes"><Donut data={stats.status} colors={["var(--chart-5)", "var(--chart-3)", "var(--chart-4)", "var(--muted-foreground)"]} /></Panel>
        <Panel title="Assinaturas por plano"><Donut data={stats.plans} colors={COLORS} /></Panel>
      </div>
      <Panel title="Atividades recentes" className="mt-6">
        {(a.data ?? []).length === 0 ? <Empty text="Nenhuma atividade ainda." /> : (
          <ul className="divide-y text-sm">{a.data!.slice(0, 12).map((x) => <li key={x.id} className="flex justify-between gap-4 py-2"><span>{x.description}</span><span className="shrink-0 text-xs text-muted-foreground">{fmtDateTime(x.created_at)}</span></li>)}</ul>
        )}
      </Panel>
    </>
  );
}

function Donut({ data, colors }: { data: { name: string; value: number }[]; colors: string[] }) {
  if (data.every((d) => d.value === 0)) return <Empty text="Sem dados ainda." />;
  return <div className="h-64"><ResponsiveContainer><PieChart><Pie data={data} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={2}>{data.map((_, i) => <Cell key={i} fill={colors[i % colors.length]} />)}</Pie><Tooltip /><Legend /></PieChart></ResponsiveContainer></div>;
}
