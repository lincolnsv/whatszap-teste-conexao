import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search, AlertTriangle } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PageHeader, StatusBadge, Loading, ErrorBox, Empty, Panel } from "@/components/app/ui";
import { useClients, useServers, usePlans } from "@/lib/data";
import { brl, clientStatus, daysBetween, fmtDate, onlyDigits, todayISO } from "@/lib/business";

export const Route = createFileRoute("/_authenticated/vencimentos")({
  head: () => ({ meta: [{ title: "Vencimentos — Fusion Gestão Pro" }, { name: "description", content: "Central de vencimentos das assinaturas." }, { property: "og:title", content: "Vencimentos — Fusion Gestão Pro" }, { property: "og:description", content: "Central de vencimentos das assinaturas." }] }),
  component: Vencimentos,
});

const CATS = [
  { k: "hoje", label: "Vencem hoje", test: (d: number) => d === 0 },
  { k: "amanha", label: "Amanhã", test: (d: number) => d === 1 },
  { k: "3", label: "Em 3 dias", test: (d: number) => d >= 2 && d <= 3 },
  { k: "7", label: "Em 7 dias", test: (d: number) => d >= 4 && d <= 7 },
  { k: "vencidos", label: "Já vencidos", test: (d: number) => d < 0 },
];

function Vencimentos() {
  const { data, isLoading, error } = useClients();
  const { data: servers = [] } = useServers();
  const { data: plans = [] } = usePlans();
  const [cat, setCat] = useState("hoje");
  const [q, setQ] = useState("");
  const [server, setServer] = useState("all");
  const today = todayISO();
  const active = (data ?? []).filter((c) => !c.suspended).map((c) => ({ c, d: daysBetween(today, c.due_date) }));
  const counts: Record<string, number> = Object.fromEntries(CATS.map((x) => [x.k, active.filter((y) => x.test(y.d)).length]));
  const hoje = counts["hoje"] ?? 0, vencidos = counts["vencidos"] ?? 0;
  const rows = useMemo(() => {
    const t = CATS.find((x) => x.k === cat)!, term = q.toLowerCase(), dg = onlyDigits(q);
    return active.filter((y) => t.test(y.d) && (server === "all" || y.c.server_id === server) && (!term || y.c.name.toLowerCase().includes(term) || (dg && onlyDigits(y.c.phone).includes(dg)))).sort((a, b) => a.d - b.d);
  }, [active, cat, q, server]);

  return (
    <>
      <PageHeader title="Central de vencimentos" subtitle="Acompanhe quem precisa renovar." />
      {(hoje > 0 || vencidos > 0) && (
        <div className="mb-4 flex items-center gap-2 rounded-lg border border-warning/40 bg-warning/15 px-4 py-3 text-sm animate-in-up"><AlertTriangle className="h-4 w-4" />{hoje} vencem hoje e {vencidos} já estão vencidos.</div>
      )}
      <Tabs value={cat} onValueChange={setCat} className="mb-4"><TabsList className="h-auto flex-wrap">{CATS.map((x) => <TabsTrigger key={x.k} value={x.k}>{x.label} ({counts[x.k]})</TabsTrigger>)}</TabsList></Tabs>
      <Panel>
        <div className="mb-4 flex flex-col gap-2 md:flex-row">
          <div className="relative flex-1"><Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" /><Input className="pl-9" placeholder="Buscar por nome ou telefone" value={q} onChange={(e) => setQ(e.target.value)} /></div>
          <Select value={server} onValueChange={setServer}><SelectTrigger className="md:w-48"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todos os servidores</SelectItem>{servers.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent></Select>
        </div>
        {isLoading ? <Loading /> : error ? <ErrorBox error={error} /> : rows.length === 0 ? <Empty text="Nenhum cliente nesta categoria." /> : (
          <div className="overflow-x-auto"><Table>
            <TableHeader><TableRow><TableHead>Cliente</TableHead><TableHead>Telefone</TableHead><TableHead>Servidor</TableHead><TableHead>Plano</TableHead><TableHead>Valor</TableHead><TableHead>Vencimento</TableHead><TableHead>Situação</TableHead><TableHead /></TableRow></TableHeader>
            <TableBody>{rows.map(({ c, d }) => (
              <TableRow key={c.id}>
                <TableCell className="font-medium">{c.name}</TableCell><TableCell>{c.phone}</TableCell>
                <TableCell>{servers.find((s) => s.id === c.server_id)?.name ?? "—"}</TableCell>
                <TableCell>{plans.find((p) => p.code === c.plan)?.label}</TableCell><TableCell>{brl(c.price)}</TableCell>
                <TableCell>{fmtDate(c.due_date)}<p className="text-xs text-muted-foreground">{d < 0 ? `há ${-d} dia(s)` : d === 0 ? "hoje" : `em ${d} dia(s)`}</p></TableCell>
                <TableCell><StatusBadge status={clientStatus(c, today)} /></TableCell>
                <TableCell><Button asChild size="sm" variant="outline"><Link to="/clientes" search={{ edit: c.id }}>Abrir</Link></Button></TableCell>
              </TableRow>))}
            </TableBody>
          </Table></div>
        )}
      </Panel>
    </>
  );
}
