import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Plus, CalendarDays, CalendarRange, Calendar, Wallet, Clock, Hash, Receipt, Check, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { PageHeader, StatCard, Loading, ErrorBox, Empty, Panel, Pill } from "@/components/app/ui";
import { PaymentDialog } from "@/components/app/dialogs";
import { usePayments, useServers, usePlans, logActivity, useRefresh } from "@/lib/data";
import { brl, fmtDate, METHOD_LABEL, todayISO } from "@/lib/business";

export const Route = createFileRoute("/_authenticated/financeiro")({
  head: () => ({ meta: [{ title: "Financeiro — Fusion Gestão Pro" }, { name: "description", content: "Faturamento, pagamentos e histórico financeiro." }, { property: "og:title", content: "Financeiro — Fusion Gestão Pro" }, { property: "og:description", content: "Faturamento, pagamentos e histórico financeiro." }] }),
  component: Financeiro,
});

function Financeiro() {
  const { data, isLoading, error } = usePayments();
  const { data: servers = [] } = useServers();
  const { data: plans = [] } = usePlans();
  const refresh = useRefresh();
  const [open, setOpen] = useState(false);
  const today = todayISO();
  const [from, setFrom] = useState(today.slice(0, 8) + "01");
  const [to, setTo] = useState(today);
  const [q, setQ] = useState("");
  const [method, setMethod] = useState("all");
  const all = data ?? [];
  const conf = all.filter((p) => p.status === "confirmado");
  const sum = (xs: typeof all) => xs.reduce((t, x) => t + Number(x.amount), 0);
  const rows = useMemo(() => all.filter((p) => p.paid_at >= from && p.paid_at <= to && (method === "all" || p.method === method) && (!q || p.client_name.toLowerCase().includes(q.toLowerCase()))), [all, from, to, q, method]);

  async function confirmPay(id: string, name: string) {
    const { error } = await supabase.from("payments").update({ status: "confirmado" }).eq("id", id);
    if (error) return void toast.error(error.message);
    await logActivity("pagamento", `Pagamento confirmado — ${name}`); toast.success("Pagamento confirmado"); refresh("payments");
  }
  async function remove(id: string, name: string) {
    if (!confirm("Excluir este pagamento?")) return;
    const { error } = await supabase.from("payments").delete().eq("id", id);
    if (error) return void toast.error(error.message);
    await logActivity("pagamento", `Pagamento excluído — ${name}`); refresh("payments");
  }

  if (isLoading) return <Loading />;
  if (error) return <ErrorBox error={error} />;
  return (
    <>
      <PageHeader title="Financeiro" actions={<Button onClick={() => setOpen(true)}><Plus className="h-4 w-4" />Registrar pagamento</Button>} />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-7">
        <StatCard label="Hoje" value={brl(sum(conf.filter((p) => p.paid_at === today)))} icon={CalendarDays} tone="success" />
        <StatCard label="Mês" value={brl(sum(conf.filter((p) => p.paid_at.startsWith(today.slice(0, 7)))))} icon={CalendarRange} tone="success" />
        <StatCard label="Ano" value={brl(sum(conf.filter((p) => p.paid_at.startsWith(today.slice(0, 4)))))} icon={Calendar} tone="success" />
        <StatCard label="Total recebido" value={brl(sum(conf))} icon={Wallet} />
        <StatCard label="Pendente" value={brl(sum(all.filter((p) => p.status === "pendente")))} icon={Clock} tone="warning" />
        <StatCard label="Pagamentos" value={conf.length} icon={Hash} tone="info" />
        <StatCard label="Ticket médio" value={brl(conf.length ? sum(conf) / conf.length : 0)} icon={Receipt} />
      </div>
      <Panel title="Histórico de pagamentos" className="mt-6">
        <div className="mb-4 grid gap-2 md:grid-cols-4">
          <Input placeholder="Buscar cliente" value={q} onChange={(e) => setQ(e.target.value)} />
          <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} aria-label="De" />
          <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} aria-label="Até" />
          <Select value={method} onValueChange={setMethod}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todas as formas</SelectItem>{Object.entries(METHOD_LABEL).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent></Select>
        </div>
        <p className="mb-2 text-sm text-muted-foreground">{rows.length} pagamento(s) no período · {brl(sum(rows.filter((r) => r.status === "confirmado")))} confirmados</p>
        {rows.length === 0 ? <Empty /> : (
          <div className="overflow-x-auto"><Table>
            <TableHeader><TableRow><TableHead>Data</TableHead><TableHead>Cliente</TableHead><TableHead>Valor</TableHead><TableHead>Forma</TableHead><TableHead>Plano</TableHead><TableHead>Servidor</TableHead><TableHead>Situação</TableHead><TableHead /></TableRow></TableHeader>
            <TableBody>{rows.map((p) => (
              <TableRow key={p.id}>
                <TableCell>{fmtDate(p.paid_at)}</TableCell><TableCell className="font-medium">{p.client_name}{p.notes && <p className="text-xs text-muted-foreground">{p.notes}</p>}</TableCell>
                <TableCell>{brl(p.amount)}</TableCell><TableCell>{METHOD_LABEL[p.method]}</TableCell>
                <TableCell>{plans.find((x) => x.code === p.plan)?.label ?? "—"}</TableCell><TableCell>{servers.find((s) => s.id === p.server_id)?.name ?? "—"}</TableCell>
                <TableCell>{p.is_renewal ? <Pill>Renovação</Pill> : <Pill tone={p.status === "pendente" ? "warning" : "success"}>{p.status === "pendente" ? "Pendente" : "Confirmado"}</Pill>}</TableCell>
                <TableCell className="whitespace-nowrap text-right">
                  {p.status === "pendente" && <Button size="sm" variant="outline" onClick={() => confirmPay(p.id, p.client_name)}><Check className="h-3.5 w-3.5" />Confirmar</Button>}
                  {!p.is_renewal && <Button size="icon" variant="ghost" aria-label="Excluir" onClick={() => remove(p.id, p.client_name)}><Trash2 className="h-4 w-4 text-destructive" /></Button>}
                </TableCell>
              </TableRow>))}
            </TableBody>
          </Table></div>
        )}
      </Panel>
      <PaymentDialog open={open} onOpenChange={setOpen} />
    </>
  );
}
