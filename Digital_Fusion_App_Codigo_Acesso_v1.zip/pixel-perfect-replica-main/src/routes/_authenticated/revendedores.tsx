import { createFileRoute } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { Plus, Pencil, Loader2, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { listResellers, createReseller, updateReseller } from "@/lib/resellers.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { PageHeader, Empty, Pill } from "@/components/app/ui";
import { fmtDateTime, fmtDate } from "@/lib/business";
import { resellerAccess } from "@/lib/reseller-access";

const options = (id: string) => queryOptions({ queryKey: ["resellers", id], queryFn: () => listResellers() });
export const Route = createFileRoute("/_authenticated/revendedores")({
  head: () => ({ meta: [{ title: "Revendedores — Fusion Gestão Pro" }, { name: "description", content: "Administração dos acessos dos revendedores." }, { property: "og:title", content: "Revendedores — Fusion Gestão Pro" }, { property: "og:description", content: "Administração dos acessos dos revendedores." }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(options(context.user.id)),
  component: Resellers,
});
type Reseller = Awaited<ReturnType<typeof listResellers>>[number];
function Resellers() {
  const { user, queryClient } = Route.useRouteContext();
  const { data: rows } = useSuspenseQuery(options(user.id));
  const create = useServerFn(createReseller), update = useServerFn(updateReseller);
  const [open, setOpen] = useState(false), [editing, setEditing] = useState<Reseller | null>(null), [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", username: "", password: "", active: true, expiresOn: "" });
  const [search, setSearch] = useState("");
  function edit(row: Reseller | null) { setEditing(row); setForm({ name: row?.name ?? "", phone: row?.phone ?? "", username: row?.username ?? "", password: "", active: row?.active ?? true, expiresOn: row?.expires_on ?? "" }); setOpen(true); }
  async function save(e: React.FormEvent) {
    e.preventDefault(); setBusy(true);
    try {
      if (editing) await update({ data: { userId: editing.user_id, name: form.name, phone: form.phone, active: form.active, expiresOn: form.expiresOn, ...(form.password ? { password: form.password } : {}) } });
      else await create({ data: form });
      await queryClient.invalidateQueries({ queryKey: ["resellers", user.id] }); setOpen(false); toast.success(editing ? "Revendedor atualizado" : "Revendedor criado");
    } catch (e) { toast.error(e instanceof Error ? e.message : "Não foi possível salvar."); } finally { setBusy(false); }
  }
  const filtered = rows.filter(r => `${r.name} ${r.username} ${r.phone}`.toLowerCase().includes(search.toLowerCase()));
  return <>
    <PageHeader title="Revendedores" subtitle="Superadministrador" actions={<Button onClick={() => edit(null)}><Plus className="h-4 w-4" />Novo revendedor</Button>} />
    <div className="mb-5 flex flex-wrap items-center gap-4 text-sm text-muted-foreground"><ShieldCheck className="h-5 w-5 text-primary" /><span>{rows.length} revendedores</span><span>{rows.filter(r => resellerAccess(r).enabled).length} ativos</span><span>{rows.filter(r => !resellerAccess(r).enabled).length} bloqueados</span></div>
    <Input className="mb-5 max-w-md" placeholder="Buscar nome, usuário ou telefone" value={search} onChange={e => setSearch(e.target.value)} />
    {filtered.length === 0 ? <Empty text="Nenhum revendedor cadastrado." /> : <div className="divide-y border-y">{filtered.map(r => <div key={r.user_id} className="flex flex-wrap items-center justify-between gap-3 py-4"><div className="min-w-0"><p className="break-words font-semibold">{r.name}</p><p className="break-words text-sm text-muted-foreground">{r.username} · {r.phone}</p><p className="text-xs text-muted-foreground">{fmtDateTime(r.created_at)}</p><p className="text-sm text-muted-foreground">Expiração: {r.expires_on ? fmtDate(r.expires_on) : "Não definida"}</p></div><div className="flex items-center gap-3"><Pill tone={resellerAccess(r).enabled ? "success" : "danger"}>{!r.active ? "Bloqueado" : resellerAccess(r).expired ? "Expirado" : "Ativo"}</Pill><Button size="icon" variant="outline" aria-label={`Editar ${r.name}`} title="Editar acesso" onClick={() => edit(r)}><Pencil className="h-4 w-4" /></Button></div></div>)}</div>}
    <Dialog open={open} onOpenChange={setOpen}><DialogContent><DialogHeader><DialogTitle>{editing ? "Editar revendedor" : "Novo revendedor"}</DialogTitle></DialogHeader><form onSubmit={save} className="space-y-4">
      <div className="space-y-1.5"><Label htmlFor="reseller-name">Nome</Label><Input id="reseller-name" required minLength={2} value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div>
      <div className="space-y-1.5"><Label htmlFor="reseller-phone">Telefone com DDD</Label><Input id="reseller-phone" required type="tel" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
      <div className="space-y-1.5"><Label htmlFor="reseller-user">Usuário</Label><Input id="reseller-user" required minLength={3} pattern="[a-zA-Z0-9._-]+" disabled={!!editing} autoComplete="off" value={form.username} onChange={e => setForm({ ...form, username: e.target.value })} /></div>
      <div className="space-y-1.5"><Label htmlFor="reseller-password">{editing ? "Nova senha (opcional)" : "Senha"}</Label><Input id="reseller-password" type="password" required={!editing} minLength={8} autoComplete="new-password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} /></div>
      <div className="space-y-1.5"><Label htmlFor="reseller-expiration">Data de expiração</Label><Input id="reseller-expiration" type="date" required value={form.expiresOn} onChange={e => setForm({ ...form, expiresOn: e.target.value })} /></div>
      {editing && <div className="flex items-center gap-3"><Switch id="reseller-active" checked={form.active} onCheckedChange={active => setForm({ ...form, active })} /><Label htmlFor="reseller-active">Acesso ativo</Label></div>}
      <DialogFooter><Button variant="outline" type="button" onClick={() => setOpen(false)}>Cancelar</Button><Button disabled={busy} type="submit">{busy && <Loader2 className="h-4 w-4 animate-spin" />}Salvar</Button></DialogFooter>
    </form></DialogContent></Dialog>
  </>;
}