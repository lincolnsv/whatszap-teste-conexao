import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { CheckCircle2, XCircle, Send, Clock, AlertTriangle, Phone, Play, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { PageHeader, StatCard, Panel, Empty, Pill, Loading } from "@/components/app/ui";
import { useNotifications, useClients, useSettings, useRefresh } from "@/lib/data";
import { getWaStatus, runRemindersNow } from "@/lib/whatsapp.functions";
import { fmtDate, fmtDateTime } from "@/lib/business";

export const Route = createFileRoute("/_authenticated/whatsapp")({
  head: () => ({ meta: [{ title: "Central WhatsApp — Fusion Gestão Pro" }, { name: "description", content: "Status da conexão e histórico de lembretes." }, { property: "og:title", content: "Central WhatsApp — Fusion Gestão Pro" }, { property: "og:description", content: "Status da conexão e histórico de lembretes." }] }),
  component: WhatsApp,
});

const STAGE: Record<string, string> = { d3: "3 dias antes", d1: "1 dia antes", d0: "No dia", manual: "Manual" };
const tone = (s: string) => (s === "falhou" ? "danger" : s === "pendente" ? "warning" : s === "entregue" || s === "lida" ? "success" : "info") as "danger";

function WhatsApp() {
  const status = useQuery({ queryKey: ["wa-status"], queryFn: () => getWaStatus() });
  const { data: logs = [], isLoading } = useNotifications();
  const { data: clients = [] } = useClients();
  const { data: settings } = useSettings();
  const refresh = useRefresh();
  const [busy, setBusy] = useState(false);
  const name = (id: string | null) => clients.find((c) => c.id === id)?.name ?? "—";
  const sent = logs.filter((l) => ["aceito", "enviada", "entregue", "lida"].includes(l.status)).length;

  async function runNow() {
    setBusy(true);
    try { const r: any = await runRemindersNow(); toast.success(r.skipped ? `Não enviado: ${r.skipped}` : `${r.sent} lembrete(s) processados`); refresh("notifications"); }
    catch (e) { toast.error(e instanceof Error ? e.message : "Erro"); } finally { setBusy(false); }
  }

  return (
    <>
      <PageHeader title="Central WhatsApp" subtitle="API oficial do WhatsApp Business (Meta)." actions={<Button onClick={runNow} disabled={busy || !status.data?.connected}>{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}Executar lembretes agora</Button>} />
      <Panel className="mb-4">
        {status.isLoading ? <Loading /> : status.data?.connected ? (
          <div className="flex flex-wrap items-center gap-4"><CheckCircle2 className="h-6 w-6 text-success" /><div><p className="font-semibold">Conectado</p><p className="flex items-center gap-1 text-sm text-muted-foreground"><Phone className="h-3.5 w-3.5" />{status.data.phone ?? "Número não informado"}</p></div>
            <Pill tone={settings?.reminders_enabled ? "success" : "warning"}>Lembretes automáticos {settings?.reminders_enabled ? "ativados" : "desativados"}</Pill></div>
        ) : (
          <div className="flex items-start gap-3"><XCircle className="h-6 w-6 shrink-0 text-destructive" /><div><p className="font-semibold">Não conectado</p><p className="text-sm text-muted-foreground">{status.data?.error ?? "Conecte sua conta do WhatsApp Business para enviar lembretes."}</p></div></div>
        )}
      </Panel>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label="Enviadas" value={sent} icon={Send} tone="success" />
        <StatCard label="Entregues" value={logs.filter((l) => l.status === "entregue" || l.status === "lida").length} icon={CheckCircle2} tone="info" />
        <StatCard label="Pendentes" value={logs.filter((l) => l.status === "pendente").length} icon={Clock} tone="warning" />
        <StatCard label="Com falha" value={logs.filter((l) => l.status === "falhou").length} icon={AlertTriangle} tone="danger" />
      </div>
      <Panel title="Histórico de notificações" className="mt-6">
        {isLoading ? <Loading /> : logs.length === 0 ? <Empty text="Nenhuma notificação enviada ainda." /> : (
          <div className="overflow-x-auto"><Table>
            <TableHeader><TableRow><TableHead>Data</TableHead><TableHead>Cliente</TableHead><TableHead>Etapa</TableHead><TableHead>Vencimento</TableHead><TableHead>Situação</TableHead><TableHead>Detalhes</TableHead></TableRow></TableHeader>
            <TableBody>{logs.map((l) => (
              <TableRow key={l.id}><TableCell className="whitespace-nowrap">{fmtDateTime(l.created_at)}</TableCell><TableCell>{name(l.client_id)}<p className="text-xs text-muted-foreground">{l.phone}</p></TableCell>
                <TableCell>{STAGE[l.stage] ?? l.stage}</TableCell><TableCell>{fmtDate(l.due_date)}</TableCell><TableCell><Pill tone={tone(l.status)}>{l.status}</Pill></TableCell>
                <TableCell className="max-w-xs break-words text-xs text-destructive">{l.error ?? ""}{l.attempts > 1 && <span className="text-muted-foreground"> ({l.attempts} tentativas)</span>}</TableCell></TableRow>))}
            </TableBody>
          </Table></div>
        )}
      </Panel>
    </>
  );
}
