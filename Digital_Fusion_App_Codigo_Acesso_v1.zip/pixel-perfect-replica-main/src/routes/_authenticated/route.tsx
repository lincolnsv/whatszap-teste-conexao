import { createFileRoute, Link, Outlet, redirect, useNavigate } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getOwnAccess } from "@/lib/resellers.functions";
import { fmtDate } from "@/lib/business";
import { Button } from "@/components/ui/button";
import { LayoutDashboard, Users, CalendarClock, Server, Wallet, MessageCircle, Settings, LogOut, Menu, Zap, ChevronsLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/" });
    return { user: data.user };
  },
  component: Shell,
});

const NAV = [
  { to: "/painel", label: "Visão geral", icon: LayoutDashboard },
  { to: "/clientes", label: "Clientes", icon: Users },
  { to: "/vencimentos", label: "Vencimentos", icon: CalendarClock },
  { to: "/servidores", label: "Servidores", icon: Server },
  { to: "/financeiro", label: "Financeiro", icon: Wallet },
  { to: "/whatsapp", label: "WhatsApp", icon: MessageCircle },
  { to: "/configuracoes", label: "Configurações", icon: Settings },
] as const;

function Shell() {
  const [open, setOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { user } = Route.useRouteContext();
  const [isAdmin, setIsAdmin] = useState(false);
  const readAccess = useServerFn(getOwnAccess);
  const access = useQuery({ queryKey: ["account-access", user.id], queryFn: () => readAccess(), refetchInterval: 30000, refetchOnWindowFocus: "always", staleTime: 0, retry: false });
  useEffect(() => {
    if (access.data?.enabled === false) {
      void qc.cancelQueries({ predicate: q => q.queryKey[0] !== "account-access" });
      qc.removeQueries({ predicate: q => q.queryKey[0] !== "account-access" });
    }
  }, [access.data?.enabled, qc]);
  useEffect(() => { setIsAdmin(false); let current = true; supabase.rpc("has_role", { _user_id: user.id, _role: "admin" }).then(({ data }) => { if (current) setIsAdmin(data === true); }); return () => { current = false; }; }, [user.id]);
  async function logout() { await qc.cancelQueries(); qc.clear(); await supabase.auth.signOut(); navigate({ to: "/", replace: true }); }
  const side = (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-3 px-4 py-5">
        <div className="bg-brand flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-primary-foreground"><Zap className="h-4 w-4" /></div>
        {!collapsed && <div className="leading-tight"><p className="font-display text-sm font-semibold text-sidebar-accent-foreground">Fusion Gestão Pro</p><p className="text-xs opacity-70">Digital Fusion</p></div>}
      </div>
      <nav className="flex-1 space-y-1 px-2">
        {NAV.map((n) => (
          <Link key={n.to} to={n.to} onClick={() => setOpen(false)} title={n.label}
            className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            activeProps={{ className: "bg-sidebar-accent text-sidebar-primary font-semibold" }}>
            <n.icon className="h-4 w-4 shrink-0" />{!collapsed && n.label}
          </Link>
        ))}
        {isAdmin && <Link to="/revendedores" onClick={() => setOpen(false)} title="Revendedores" className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm hover:bg-sidebar-accent" activeProps={{ className: "bg-sidebar-accent text-sidebar-primary font-semibold" }}><Users className="h-4 w-4 shrink-0" />{!collapsed && "Revendedores"}</Link>}
      </nav>
      <div className="space-y-1 border-t border-sidebar-border p-2">
        <button onClick={() => setCollapsed(!collapsed)} className="hidden w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm hover:bg-sidebar-accent lg:flex"><ChevronsLeft className={cn("h-4 w-4 transition-transform", collapsed && "rotate-180")} />{!collapsed && "Recolher"}</button>
        <Button variant="ghost" onClick={logout} className="flex w-full justify-start gap-3 rounded-lg px-3 py-2.5 text-sm hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"><LogOut className="h-4 w-4" />{!collapsed && "Sair"}</Button>
      </div>
    </div>
  );
  return (
    <div className="flex min-h-screen">
      <aside className={cn("sticky top-0 hidden h-screen shrink-0 bg-sidebar text-sidebar-foreground transition-all lg:block", collapsed ? "w-[72px]" : "w-64")}>{side}</aside>
      {open && <div className="fixed inset-0 z-40 bg-foreground/40 lg:hidden" onClick={() => setOpen(false)} />}
      <aside className={cn("fixed inset-y-0 left-0 z-50 w-64 bg-sidebar text-sidebar-foreground transition-transform lg:hidden", open ? "translate-x-0" : "-translate-x-full")}>{side}</aside>
      <div className="min-w-0 flex-1">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b bg-background/90 px-4 py-3 backdrop-blur lg:hidden">
          <button aria-label="Abrir menu" onClick={() => setOpen(true)}><Menu className="h-5 w-5" /></button>
          <span className="font-display font-semibold">Fusion Gestão Pro</span>
        </header>
        <main className="mx-auto max-w-7xl p-4 md:p-8">
          {access.isPending ? <p role="status">Verificando acesso…</p> : access.isError ? <div role="alert" className="space-y-3"><p>Não foi possível verificar seu acesso.</p><Button onClick={() => access.refetch()}>Tentar novamente</Button></div> : !access.data.enabled ? <section role="alert" className="space-y-3"><h1 className="text-2xl font-semibold">{access.data.expired ? "Seu acesso expirou" : "Seu acesso está bloqueado"}</h1><p className="text-muted-foreground">{access.data.expired ? `Seu painel expirou em ${fmtDate(access.data.expiresOn)}. Entre em contato com o administrador para renovar.` : "Entre em contato com o administrador para liberar seu acesso."}</p><Button onClick={() => access.refetch()}>Verificar renovação</Button></section> : <>
            {access.data.warn && <div role="alert" className="mb-6 border-l-4 border-destructive bg-destructive/10 p-4"><p className="font-semibold">Falta{access.data.daysRemaining === 1 ? "" : "m"} {access.data.daysRemaining} dia{access.data.daysRemaining === 1 ? "" : "s"} para bloquear seu painel.</p><p className="text-sm">Renove seu acesso até {fmtDate(access.data.expiresOn)} para evitar o bloqueio. Entre em contato com o administrador.</p></div>}
            <Outlet />
          </>}
        </main>
      </div>
    </div>
  );
}
