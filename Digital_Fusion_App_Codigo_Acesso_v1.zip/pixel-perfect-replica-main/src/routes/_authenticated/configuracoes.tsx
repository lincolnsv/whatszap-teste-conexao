import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { PageHeader, Panel, Loading, Empty } from "@/components/app/ui";
import { useSettings, usePlans, useActivity, logActivity, useRefresh } from "@/lib/data";
import { fmtDateTime } from "@/lib/business";

export const Route = createFileRoute("/_authenticated/configuracoes")({
  head: () => ({ meta: [{ title: "Configurações — Fusion Gestão Pro" }, { name: "description", content: "Planos, Pix, lembretes e dados do sistema." }, { property: "og:title", content: "Configurações — Fusion Gestão Pro" }, { property: "og:description", content: "Planos, Pix, lembretes e dados do sistema." }] }),
  component: Config,
});

const TEMPLATE = `Olá, {{1}}! 😊

Tudo bem?

Estamos passando para lembrar que sua assinatura do Digital Fusion vence em {{2}}.

💰 Valor da renovação: {{3}}

💠 PAGAMENTO VIA PIX

Chave Pix: {{4}}

Titular: {{5}}

Após realizar o pagamento, envie seu comprovante para confirmação da renovação.

Obrigado pela preferência!

Equipe Digital Fusion ❤️`;

function Config() {
  const { data: s, isLoading } = useSettings();
  const { data: plans = [] } = usePlans();
  const { data: activity = [] } = useActivity();
  const refresh = useRefresh();
  const [f, setF] = useState<any>(null);
  const [prices, setPrices] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (s) setF(s); }, [s]);
  useEffect(() => { setPrices(Object.fromEntries(plans.map((p) => [p.code, String(p.price)]))); }, [plans]);

  async function save() {
    setBusy(true);
    const hour = Math.min(23, Math.max(0, Number(f.send_hour) || 9));
    const { error } = await supabase.from("account_settings").update({ system_name: f.system_name, company_name: f.company_name, pix_key: f.pix_key, pix_holder: f.pix_holder, reminders_enabled: f.reminders_enabled, send_hour: hour, template_name: f.template_name, template_lang: f.template_lang, updated_at: new Date().toISOString() }).eq("owner_id", s?.owner_id ?? "");
    for (const p of plans) {
      const v = Number(prices[p.code]);
      if (v > 0 && v !== Number(p.price)) { const r = await supabase.from("account_plans").update({ price: v }).eq("owner_id", p.owner_id).eq("code", p.code); if (r.error) { toast.error(r.error.message); } }
    }
    setBusy(false);
    if (error) return void toast.error(error.message);
    await logActivity("config", "Configurações do sistema alteradas");
    toast.success("Configurações salvas"); refresh("settings", "plans");
  }

  if (isLoading || !f) return <Loading />;
  const field = (k: string, label: string) => <div className="space-y-1.5"><Label>{label}</Label><Input value={f[k] ?? ""} onChange={(e) => setF({ ...f, [k]: e.target.value })} /></div>;
  return (
    <>
      <PageHeader title="Configurações" actions={<Button onClick={save} disabled={busy}>{busy && <Loader2 className="h-4 w-4 animate-spin" />}Salvar alterações</Button>} />
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title="Sistema e empresa"><div className="space-y-3">{field("system_name", "Nome do sistema")}{field("company_name", "Nome da empresa")}</div></Panel>
        <Panel title="Pagamento via Pix"><div className="space-y-3">{field("pix_key", "Chave Pix")}{field("pix_holder", "Titular")}</div></Panel>
        <Panel title="Valores dos planos (R$)"><div className="grid grid-cols-2 gap-3">{plans.map((p) => <div key={p.code} className="space-y-1.5"><Label>{p.label} ({p.months} {p.months === 1 ? "mês" : "meses"})</Label><Input type="number" step="0.01" min="0" value={prices[p.code] ?? ""} onChange={(e) => setPrices({ ...prices, [p.code]: e.target.value })} /></div>)}</div></Panel>
        <Panel title="Lembretes automáticos">
          <div className="space-y-3">
            <label className="flex items-center gap-2 text-sm"><Switch checked={f.reminders_enabled} onCheckedChange={(v) => setF({ ...f, reminders_enabled: v })} />Enviar lembretes 3 dias antes, 1 dia antes e no dia do vencimento</label>
            <p className="text-xs text-muted-foreground">Só recebem clientes marcados com “Aceita lembretes no WhatsApp”. Cada etapa é enviada uma única vez por vencimento. Envio diário por volta das 9h (horário de Brasília).</p>
            {field("template_name", "Nome do modelo aprovado na Meta")}{field("template_lang", "Idioma do modelo")}
          </div>
        </Panel>
        <Panel title="Texto do modelo para cadastrar na Meta" className="lg:col-span-2">
          <p className="mb-2 text-xs text-muted-foreground">Variáveis: {"{{1}}"} nome, {"{{2}}"} vencimento, {"{{3}}"} valor, {"{{4}}"} chave Pix, {"{{5}}"} titular. Categoria: Utilidade.</p>
          <pre className="whitespace-pre-wrap rounded-lg bg-muted p-3 text-sm">{TEMPLATE}</pre>
        </Panel>
        <Panel title="Histórico de atividades" className="lg:col-span-2">
          {activity.length === 0 ? <Empty /> : <ul className="max-h-96 divide-y overflow-y-auto text-sm">{activity.map((a) => <li key={a.id} className="flex justify-between gap-4 py-2"><span>{a.description}</span><span className="shrink-0 text-xs text-muted-foreground">{fmtDateTime(a.created_at)}</span></li>)}</ul>}
        </Panel>
      </div>
    </>
  );
}
