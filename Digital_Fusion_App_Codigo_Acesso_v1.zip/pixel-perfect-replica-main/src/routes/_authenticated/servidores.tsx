import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Plus, Pencil, Trash2, Server, Users } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PageHeader, Loading, ErrorBox, Empty, Pill } from "@/components/app/ui";
import { type ServerRow, useServers, useClients, logActivity, useRefresh } from "@/lib/data";

export const Route = createFileRoute("/_authenticated/servidores")({
  head: () => ({ meta: [{ title: "Servidores — Fusion Gestão Pro" }, { name: "description", content: "Cadastro e status dos servidores." }, { property: "og:title", content: "Servidores — Fusion Gestão Pro" }, { property: "og:description", content: "Cadastro e status dos servidores." }] }),
  component: Servidores,
});

function Servidores() {
  const { data, isLoading, error } = useServers();
  const { data: clients = [] } = useClients();
  const refresh = useRefresh();
  const [edit, setEdit] = useState<ServerRow | null>(null);
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ name: "", address: "", description: "", active: true, notes: "" });
  useEffect(() => { if (open) setF(edit ? { name: edit.name, address: edit.address ?? "", description: edit.description ?? "", active: edit.active, notes: edit.notes ?? "" } : { name: "", address: "", description: "", active: true, notes: "" }); }, [open, edit]);
  const count = (id: string) => clients.filter((c) => c.server_id === id).length;

  async function save() {
    if (!f.name.trim()) return void toast.error("Informe o nome do servidor.");
    const row = { name: f.name.trim(), address: f.address || null, description: f.description || null, active: f.active, notes: f.notes || null };
    const { error } = edit ? await supabase.from("servers").update(row).eq("id", edit.id) : await supabase.from("servers").insert(row);
    if (error) return void toast.error(error.message);
    await logActivity("servidor", `${edit ? "Servidor alterado" : "Servidor cadastrado"}: ${row.name}`);
    toast.success("Servidor salvo"); setOpen(false); refresh("servers");
  }
  async function toggle(s: ServerRow) {
    const { error } = await supabase.from("servers").update({ active: !s.active }).eq("id", s.id);
    if (error) return void toast.error(error.message);
    await logActivity("servidor", `Servidor ${s.name} ${s.active ? "desativado" : "ativado"}`); refresh("servers");
  }
  async function remove(s: ServerRow) {
    if (count(s.id) > 0) return void toast.error(`Não é possível excluir: ${count(s.id)} cliente(s) vinculados. Mova-os ou desative o servidor.`);
    if (!confirm(`Excluir o servidor ${s.name}?`)) return;
    const { error } = await supabase.from("servers").delete().eq("id", s.id);
    if (error) return void toast.error(error.message);
    await logActivity("servidor", `Servidor excluído: ${s.name}`); toast.success("Servidor excluído"); refresh("servers");
  }

  return (
    <>
      <PageHeader title="Servidores" subtitle={`${data?.length ?? 0} servidores`} actions={<Button onClick={() => { setEdit(null); setOpen(true); }}><Plus className="h-4 w-4" />Novo servidor</Button>} />
      {isLoading ? <Loading /> : error ? <ErrorBox error={error} /> : !data?.length ? <Empty text="Nenhum servidor cadastrado." /> : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{data.map((s) => (
          <div key={s.id} className="rounded-xl border bg-card p-4 shadow-card animate-in-up">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3"><span className="flex h-9 w-9 items-center justify-center rounded-lg bg-accent text-accent-foreground"><Server className="h-4 w-4" /></span><div><p className="font-semibold">{s.name}</p><p className="text-xs text-muted-foreground">{s.address || "Sem endereço"}</p></div></div>
              <Pill tone={s.active ? "success" : "danger"}>{s.active ? "Ativo" : "Inativo"}</Pill>
            </div>
            {s.description && <p className="mt-3 text-sm text-muted-foreground">{s.description}</p>}
            <div className="mt-4 flex items-center justify-between">
              <Link to="/clientes" className="flex items-center gap-1.5 text-sm text-primary hover:underline"><Users className="h-4 w-4" />{count(s.id)} clientes</Link>
              <div className="flex items-center gap-1"><Switch checked={s.active} onCheckedChange={() => toggle(s)} aria-label="Ativar ou desativar" />
                <Button size="icon" variant="ghost" aria-label="Editar" onClick={() => { setEdit(s); setOpen(true); }}><Pencil className="h-4 w-4" /></Button>
                <Button size="icon" variant="ghost" aria-label="Excluir" onClick={() => remove(s)}><Trash2 className="h-4 w-4 text-destructive" /></Button></div>
            </div>
          </div>))}
        </div>
      )}
      <Dialog open={open} onOpenChange={setOpen}><DialogContent>
        <DialogHeader><DialogTitle>{edit ? "Editar servidor" : "Novo servidor"}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5"><Label>Nome</Label><Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>Endereço ou DNS</Label><Input value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>Descrição</Label><Input value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>Observações</Label><Textarea value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></div>
          <label className="flex items-center gap-2 text-sm"><Switch checked={f.active} onCheckedChange={(v) => setF({ ...f, active: v })} />Ativo</label>
        </div>
        <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button><Button onClick={save}>Salvar</Button></DialogFooter>
      </DialogContent></Dialog>
    </>
  );
}
