import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Eye, EyeOff, Loader2, Zap } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getSetupState, createFirstAdmin } from "@/lib/setup.functions";
import { usernameToEmail } from "@/lib/business";
import { resellerAccess } from "@/lib/reseller-access";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Entrar — Fusion Gestão Pro" },
      { name: "description", content: "Acesse o painel administrativo do Fusion Gestão Pro." },
      { property: "og:title", content: "Entrar — Fusion Gestão Pro" },
      { property: "og:description", content: "Acesse o painel administrativo do Fusion Gestão Pro." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Login,
});

function friendlyError(msg: string) {
  if (/weak|breach|easy to guess|too short/i.test(msg)) {
    return "Senha muito fraca ou muito comum. Use pelo menos 8 caracteres, misturando letras, números e símbolos.";
  }
  return msg;
}

function Login() {
  const navigate = useNavigate();
  const [hasAdmin, setHasAdmin] = useState<boolean | null>(null);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => { if (data.user) navigate({ to: "/painel" }); });
    getSetupState().then((s) => setHasAdmin(s.hasAdmin)).catch(() => setHasAdmin(true));
  }, [navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setError(null); setBusy(true);
    try {
      if (hasAdmin === false) await createFirstAdmin({ data: { username, password } });
      const { data: signedIn, error } = await supabase.auth.signInWithPassword({ email: usernameToEmail(username), password });
      if (error || !signedIn.user) throw new Error("Usuário ou senha incorretos.");
      const { data: account, error: accountError } = await supabase.from("reseller_accounts").select("active,expires_on").eq("user_id", signedIn.user.id).maybeSingle();
      if (accountError) { await supabase.auth.signOut(); throw new Error("Não foi possível verificar seu acesso. Tente novamente."); }
      if (account?.active === false) { await supabase.auth.signOut(); throw new Error("Seu acesso está bloqueado. Entre em contato com o administrador."); }
      const { data: enabled, error: accessError } = await supabase.rpc("account_access_enabled", { _id: signedIn.user.id });
      if (accessError || !enabled) { await supabase.auth.signOut(); throw new Error(!accessError && resellerAccess(account).expired ? "Seu acesso expirou. Entre em contato com o administrador para renovar." : "Não foi possível liberar seu acesso. Entre em contato com o administrador."); }
      navigate({ to: "/painel" });
    } catch (err) { setError(friendlyError(err instanceof Error ? err.message : "Erro ao entrar")); }
    finally { setBusy(false); }
  }

  const setup = hasAdmin === false;
  return (
    <div className="bg-auth flex min-h-screen items-center justify-center p-4">
      <div className="w-full max-w-sm animate-in-up rounded-2xl border border-sidebar-border bg-card p-8 shadow-card">
        <div className="mb-6 flex items-center gap-3">
          <div className="bg-brand flex h-11 w-11 items-center justify-center rounded-xl text-primary-foreground"><Zap className="h-5 w-5" /></div>
          <div><h1 className="text-xl font-semibold">Fusion Gestão Pro</h1><p className="text-xs text-muted-foreground">Digital Fusion</p></div>
        </div>
        <h2 className="text-lg font-semibold">{setup ? "Criar administrador" : "Entrar no painel"}</h2>
        <p className="mb-5 text-sm text-muted-foreground">{setup ? "Primeiro acesso: defina o usuário e a senha do administrador." : "Use seu usuário e senha."}</p>
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-1.5"><Label htmlFor="u">Usuário</Label><Input id="u" value={username} onChange={(e) => setUsername(e.target.value)} autoComplete="username" required minLength={3} /></div>
          <div className="space-y-1.5"><Label htmlFor="p">Senha</Label>
            <div className="relative">
              <Input id="p" type={show ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete={setup ? "new-password" : "current-password"} required minLength={setup ? 8 : 1} className="pr-10" />
              <button type="button" aria-label={show ? "Ocultar senha" : "Mostrar senha"} onClick={() => setShow(!show)} className="absolute inset-y-0 right-0 flex w-10 items-center justify-center text-muted-foreground hover:text-foreground">{show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button>
            </div>
            {setup && <p className="text-xs text-muted-foreground">Mínimo de 8 caracteres. Evite senhas muito comuns.</p>}
          </div>
          {error && <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p>}
          <Button type="submit" className="w-full" disabled={busy || hasAdmin === null}>{busy && <Loader2 className="h-4 w-4 animate-spin" />}{setup ? "Criar e entrar" : "Entrar"}</Button>
        </form>
      </div>
    </div>
  );
}
